﻿Imports MySql.Data.MySqlClient
Public Class edit_data_pindah
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_pindah As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Sub Data_Record()
        tb_pindah = Proses.ExecuteQuery("Select id_pindah,nik,nama,tempat_lahir,tanggal_lahir,jenis_kelamin,agama,kewarganegaraan, alamat_asal,alamat_sekarang,tanggal_pindah From tb_pindah  order by id_pindah DESC")
        Menu_Data_Pindah.DataGridView1.DataSource = tb_pindah
        Menu_Data_Pindah.DataGridView1.Columns(0).HeaderText = "ID"
        Menu_Data_Pindah.DataGridView1.Columns(0).Width = 100
        Menu_Data_Pindah.DataGridView1.Columns(1).HeaderText = "NIK"
        Menu_Data_Pindah.DataGridView1.Columns(1).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(2).HeaderText = "NAMA"
        Menu_Data_Pindah.DataGridView1.Columns(2).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(3).HeaderText = "TEMPAT LAHIR"
        Menu_Data_Pindah.DataGridView1.Columns(3).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(4).HeaderText = "TGL LAHIR"
        Menu_Data_Pindah.DataGridView1.Columns(4).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(5).HeaderText = "JENIS KELAMIN"
        Menu_Data_Pindah.DataGridView1.Columns(5).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(6).HeaderText = "AGAMA"
        Menu_Data_Pindah.DataGridView1.Columns(6).Width = 100
        Menu_Data_Pindah.DataGridView1.Columns(7).HeaderText = "KEWARGANEGARAAN"
        Menu_Data_Pindah.DataGridView1.Columns(7).Width = 100
        Menu_Data_Pindah.DataGridView1.Columns(8).HeaderText = "ALAMAT ASAL"
        Menu_Data_Pindah.DataGridView1.Columns(8).Width = 200
        Menu_Data_Pindah.DataGridView1.Columns(9).HeaderText = "ALAMAT SEKARANG"
        Menu_Data_Pindah.DataGridView1.Columns(9).Width = 200
        Menu_Data_Pindah.DataGridView1.Columns(10).HeaderText = "TANGGAL PINDAH"
        Menu_Data_Pindah.DataGridView1.Columns(10).Width = 100
    End Sub
    Sub Clear()
        etxt_nama.Text = ""
        etxt_tempat_lahir.Text = ""
        etxt_tgl_lahir.Value = Date.Now
        etxt_tgl_pindah.Value = Date.Now
        etxt_alamat_asal.Text = ""
        ecmb_agama.Text = ""
        cmb_kw.Text = ""
        etxt_tempat_lahir.Text = ""
        etxt_alamat_asal.Text = ""
        etxt_alamat_sekarang.Text = ""
    End Sub
    Private Sub ebtn_simpan_Click(sender As Object, e As EventArgs) Handles ebtn_simpan.Click
        Dim jk As New TextBox
        If (erbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If
        If etxt_nik.Text = "" Then etxt_nik.Focus() : Exit Sub
        If etxt_tempat_lahir.Text = "" Then etxt_tempat_lahir.Focus() : Exit Sub
        If etxt_alamat_sekarang.Text = "" Then etxt_alamat_sekarang.Focus() : Exit Sub
        If etxt_alamat_asal.Text = "" Then etxt_alamat_asal.Focus() : Exit Sub
        SQL = "update tb_pindah set nik = '" & etxt_nik.Text & "', nama = '" & etxt_nama.Text & "', tempat_lahir = '" & etxt_tempat_lahir.Text & "',tanggal_lahir = '" & Format(etxt_tgl_lahir.Value, "yyyy-MM-dd") & "' , jenis_kelamin = '" & jk.Text & "',agama = '" & ecmb_agama.Text & "',agama = '" & cmb_kw.Text & "',alamat_asal = '" & etxt_alamat_asal.Text & "',alamat_sekarang = '" & etxt_alamat_sekarang.Text & "',tanggal_pindah = '" & Format(etxt_tgl_pindah.Value, "yyyy-MM-dd") & "' where id_pindah='" & etxt_id.Text & "'"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Disimpan", "Success Message", MessageBoxButtons.OK)
        Me.Close()
        Call Data_Record()
    End Sub
End Class