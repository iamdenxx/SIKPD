﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.DataVisualization.Charting
Imports DevExpress.XtraReports.UI
Public Class Menu_Data_Kematian
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_kematian As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Dim DataPenjualan As New Koneksi
    Dim oDataTabelPenjualan2 As New DataTable
    Sub Data_Record()
        tb_kematian = Proses.ExecuteQuery("Select nik,nama,tempat_lahir,tgl_lahir,jenis_kelamin,alamat, agama,tempat_meninggal,tanggal_kematian From tb_kematian order by tgl DESC")
         DataGridView1.DataSource = tb_kematian
        DataGridView1.Columns(0).HeaderText = "NIK"
        DataGridView1.Columns(0).Width = 150
        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).HeaderText = "ALAMAT"
        DataGridView1.Columns(5).Width = 200
        DataGridView1.Columns(6).HeaderText = "AGAMA"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "TEMPAT MENINGGAL"
        DataGridView1.Columns(7).Width = 200
        DataGridView1.Columns(8).HeaderText = "TGL MENINGGAL"
        DataGridView1.Columns(8).Width = 100
    End Sub

    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        DataGridView1.Rows(e.RowIndex).HeaderCell.Value = CStr(e.RowIndex + 1)
    End Sub

    Private Sub Menu_Data_Kematian_Load(sender As Object, e As EventArgs) Handles Me.Load
        Label3.Text = Format(Now, "yyyy")
        Call Data_Chart()
        Call Data_Record()
    End Sub

    Private Sub btn_tambah_Click(sender As Object, e As EventArgs) Handles btn_tambah.Click
        tambah_data_kematian.ShowDialog()
    End Sub

    Private Sub btn_edit_Click(sender As Object, e As EventArgs) Handles btn_edit.Click

        edit_data_kematian.etxt_nik.Text = DataGridView1.SelectedCells.Item(0).Value
        edit_data_kematian.etxt_nama.Text = DataGridView1.SelectedCells.Item(1).Value
        edit_data_kematian.etxt_tempat_lahir.Text = DataGridView1.SelectedCells.Item(2).Value
        edit_data_kematian.etxt_tgl.Value = DataGridView1.SelectedCells.Item(3).Value
        If DataGridView1.SelectedCells.Item(4).Value = "Laki-Laki" Then
            edit_data_kematian.erbtn_L.Checked = True
        Else
            edit_data_kematian.erbtn_P.Checked = True

        End If
        edit_data_kematian.etxt_alamat.Text = DataGridView1.SelectedCells.Item(5).Value
        edit_data_kematian.ecmb_agama.Text = DataGridView1.SelectedCells.Item(6).Value
        edit_data_kematian.etxt_tempat_meninggal.Text = DataGridView1.SelectedCells.Item(7).Value
        edit_data_kematian.etxt_tgl_meninggal.Value = DataGridView1.SelectedCells.Item(8).Value
        edit_data_kematian.ShowDialog()
    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        SQL = "Select * from tb_kematian " & _
          " where nik like '%" & txtCari.Text & "%' or nama like  '%" & txtCari.Text & "%' or tanggal_kematian like '%" & txtCari.Text & "%'"

        tb_kematian.Clear()
        tb_kematian = Proses.ExecuteQuery(SQL)
        DataGridView1.DataSource = tb_kematian
        DataGridView1.Columns(0).HeaderText = "NIK"
        DataGridView1.Columns(0).Width = 150
        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).HeaderText = "ALAMAT"
        DataGridView1.Columns(5).Width = 200
        DataGridView1.Columns(6).HeaderText = "AGAMA"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "TEMPAT MENINGGAL"
        DataGridView1.Columns(7).Width = 200
        DataGridView1.Columns(8).HeaderText = "TGL MENINGGAL"
        DataGridView1.Columns(8).Width = 100
    End Sub

    Private Sub btncari_Click(sender As Object, e As EventArgs) Handles btncari.Click
        SQL = "Select * from tb_kematian " & _
          " where nik like '%" & txtCari.Text & "%' or nama like  '%" & txtCari.Text & "%' or tanggal_kematian like '%" & txtCari.Text & "%'"

        tb_kematian.Clear()
        tb_kematian = Proses.ExecuteQuery(SQL)
        DataGridView1.DataSource = tb_kematian
        DataGridView1.Columns(0).HeaderText = "NIK"
        DataGridView1.Columns(0).Width = 150
        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).HeaderText = "ALAMAT"
        DataGridView1.Columns(5).Width = 200
        DataGridView1.Columns(6).HeaderText = "AGAMA"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "TEMPAT MENINGGAL"
        DataGridView1.Columns(7).Width = 200
        DataGridView1.Columns(8).HeaderText = "TGL MENINGGAL"
        DataGridView1.Columns(8).Width = 100
    End Sub

    Sub Data_Chart()
        conn = New MySqlConnection
        conn.ConnectionString =
       "server=localhost;userid=root;password=;database=sikpd"
        Dim READER As MySqlDataReader

        Try
            conn.Open()
            Dim Query As String
            Query = "SELECT DATE_FORMAT(tgl,'%M') as bln, COUNT(*)AS jmlh FROM tb_kematian where YEAR(tgl)='" & Label3.Text & "' GROUP BY MONTH(tgl)"
            cd = New MySqlCommand(Query, conn)
            READER = cd.ExecuteReader
            While READER.Read

                Chart1.Series("Data Kematian").Points.AddXY(READER("bln"), READER("jmlh"))


            End While
            conn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try
    End Sub
    Sub loadDataDetail()
        oDataTabelPenjualan2.Clear()
        oDataTabelPenjualan2 = DataPenjualan.ExecuteQuery("SELECT nama, jenis_kelamin,tempat_lahir,tgl_lahir,agama,alamat,tanggal_kematian from tb_kematian WHERE nik = '" & DataGridView1.SelectedCells.Item(0).Value & "'")

    End Sub
    Private Sub CetakLaporanPenjualan(ByVal oDataTabel As DataTable)


        Dim ReportLapPenjualan As New lap_kematian
        Dim Tool As ReportPrintTool = New ReportPrintTool(ReportLapPenjualan)
        Dim oDataSet As New DataSet
        Dim oDataSet2 As New DataSet
        Dim tlahir As New TextBox
        Dim tmati As New TextBox
        Dim tmati1 As New TextBox

        tlahir.Text = Format(DataGridView1.SelectedCells.Item(3).Value, "dd - MM - yyyy")
        tmati.Text = Format(DataGridView1.SelectedCells.Item(8).Value, "dd - MM - yyyy")
        tmati1.Text = Format(DataGridView1.SelectedCells.Item(8).Value, "dd - MM - yyyy")

        Try
            If oDataSet.Tables.Count <> 0 Then
                oDataSet.Tables.Remove("Table1")
            End If
            oDataSet.Tables.Add(oDataTabelPenjualan2.Copy)

            ReportLapPenjualan.DataSource = oDataSet
            ReportLapPenjualan.DataMember = "Table1"

            ReportLapPenjualan.nama.DataBindings.Add("Text", Nothing, "nama")
            ReportLapPenjualan.jk.DataBindings.Add("Text", Nothing, "jenis_kelamin")
            ReportLapPenjualan.tempat.DataBindings.Add("Text", Nothing, "tempat_lahir")
            ReportLapPenjualan.tgl.Text = tlahir.Text
            ReportLapPenjualan.alamat.DataBindings.Add("Text", Nothing, "alamat")
            ReportLapPenjualan.agm.DataBindings.Add("Text", Nothing, "agama")
            ReportLapPenjualan.tglm.Text = tmati.Text
            ReportLapPenjualan.tm.Text = tmati1.Text

            Tool.ShowPreview()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btn_print_Click(sender As Object, e As EventArgs) Handles btn_print.Click
        loadDataDetail()
        CetakLaporanPenjualan(oDataTabelPenjualan2)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
         Halaman_Utama.Show()
        Me.Close()
    End Sub
End Class