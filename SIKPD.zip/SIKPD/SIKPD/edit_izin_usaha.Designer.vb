﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class edit_izin_usaha
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.etxt_tgl_pengajuan = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.etxt_alamat_usaha = New System.Windows.Forms.RichTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.etxt_bidang_usaha = New System.Windows.Forms.TextBox()
        Me.etxt_nama_usaha = New System.Windows.Forms.TextBox()
        Me.etxt_alamat = New System.Windows.Forms.RichTextBox()
        Me.erbtn_P = New System.Windows.Forms.RadioButton()
        Me.etxt_tempat_lahir = New System.Windows.Forms.TextBox()
        Me.etxt_nama = New System.Windows.Forms.TextBox()
        Me.erbtn_L = New System.Windows.Forms.RadioButton()
        Me.etxt_tgl_lahir = New System.Windows.Forms.DateTimePicker()
        Me.ecmb_agama = New System.Windows.Forms.ComboBox()
        Me.etxt_nik = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.ebtn_batal = New System.Windows.Forms.Button()
        Me.ebtn_simpan = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.etxt_id = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(83, 37)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(89, 16)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "TGL Pengajuan"
        '
        'etxt_tgl_pengajuan
        '
        Me.etxt_tgl_pengajuan.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_pengajuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_pengajuan.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl_pengajuan.Location = New System.Drawing.Point(184, 34)
        Me.etxt_tgl_pengajuan.Name = "etxt_tgl_pengajuan"
        Me.etxt_tgl_pengajuan.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl_pengajuan.TabIndex = 42
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(50, 439)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(122, 16)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "Alamat Tempat Usaha"
        '
        'etxt_alamat_usaha
        '
        Me.etxt_alamat_usaha.Location = New System.Drawing.Point(184, 438)
        Me.etxt_alamat_usaha.Name = "etxt_alamat_usaha"
        Me.etxt_alamat_usaha.Size = New System.Drawing.Size(200, 58)
        Me.etxt_alamat_usaha.TabIndex = 40
        Me.etxt_alamat_usaha.Text = ""
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(88, 402)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 16)
        Me.Label9.TabIndex = 39
        Me.Label9.Text = "Bidang Usaha"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(97, 362)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(73, 16)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Nama Usaha"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(126, 323)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 16)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "Agama"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(126, 249)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 16)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Alamat"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(89, 218)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 16)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Jenis Kelamin"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(110, 195)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 16)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "TGL Lahir"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(93, 159)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 16)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Tempat Lahir"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(133, 118)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 16)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(143, 77)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 16)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "NIK"
        '
        'etxt_bidang_usaha
        '
        Me.etxt_bidang_usaha.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_bidang_usaha.Location = New System.Drawing.Point(184, 396)
        Me.etxt_bidang_usaha.Name = "etxt_bidang_usaha"
        Me.etxt_bidang_usaha.Size = New System.Drawing.Size(200, 26)
        Me.etxt_bidang_usaha.TabIndex = 30
        '
        'etxt_nama_usaha
        '
        Me.etxt_nama_usaha.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nama_usaha.Location = New System.Drawing.Point(184, 356)
        Me.etxt_nama_usaha.Name = "etxt_nama_usaha"
        Me.etxt_nama_usaha.Size = New System.Drawing.Size(200, 26)
        Me.etxt_nama_usaha.TabIndex = 29
        '
        'etxt_alamat
        '
        Me.etxt_alamat.Location = New System.Drawing.Point(184, 249)
        Me.etxt_alamat.Name = "etxt_alamat"
        Me.etxt_alamat.Size = New System.Drawing.Size(200, 58)
        Me.etxt_alamat.TabIndex = 28
        Me.etxt_alamat.Text = ""
        '
        'erbtn_P
        '
        Me.erbtn_P.AutoSize = True
        Me.erbtn_P.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_P.Location = New System.Drawing.Point(297, 218)
        Me.erbtn_P.Name = "erbtn_P"
        Me.erbtn_P.Size = New System.Drawing.Size(96, 20)
        Me.erbtn_P.TabIndex = 27
        Me.erbtn_P.TabStop = True
        Me.erbtn_P.Text = "Perempuan"
        Me.erbtn_P.UseVisualStyleBackColor = True
        '
        'etxt_tempat_lahir
        '
        Me.etxt_tempat_lahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tempat_lahir.Location = New System.Drawing.Point(184, 153)
        Me.etxt_tempat_lahir.Name = "etxt_tempat_lahir"
        Me.etxt_tempat_lahir.Size = New System.Drawing.Size(200, 26)
        Me.etxt_tempat_lahir.TabIndex = 26
        '
        'etxt_nama
        '
        Me.etxt_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nama.Location = New System.Drawing.Point(184, 112)
        Me.etxt_nama.Name = "etxt_nama"
        Me.etxt_nama.Size = New System.Drawing.Size(200, 26)
        Me.etxt_nama.TabIndex = 25
        '
        'erbtn_L
        '
        Me.erbtn_L.AutoSize = True
        Me.erbtn_L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_L.Location = New System.Drawing.Point(184, 218)
        Me.erbtn_L.Name = "erbtn_L"
        Me.erbtn_L.Size = New System.Drawing.Size(80, 20)
        Me.erbtn_L.TabIndex = 24
        Me.erbtn_L.TabStop = True
        Me.erbtn_L.Text = "Laki-Laki"
        Me.erbtn_L.UseVisualStyleBackColor = True
        '
        'etxt_tgl_lahir
        '
        Me.etxt_tgl_lahir.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl_lahir.Location = New System.Drawing.Point(184, 190)
        Me.etxt_tgl_lahir.Name = "etxt_tgl_lahir"
        Me.etxt_tgl_lahir.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl_lahir.TabIndex = 23
        '
        'ecmb_agama
        '
        Me.ecmb_agama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ecmb_agama.FormattingEnabled = True
        Me.ecmb_agama.Location = New System.Drawing.Point(184, 317)
        Me.ecmb_agama.Name = "ecmb_agama"
        Me.ecmb_agama.Size = New System.Drawing.Size(121, 28)
        Me.ecmb_agama.TabIndex = 22
        '
        'etxt_nik
        '
        Me.etxt_nik.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nik.Location = New System.Drawing.Point(184, 71)
        Me.etxt_nik.Name = "etxt_nik"
        Me.etxt_nik.Size = New System.Drawing.Size(200, 26)
        Me.etxt_nik.TabIndex = 21
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Adobe Fan Heiti Std B", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(158, 9)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(228, 30)
        Me.Label31.TabIndex = 55
        Me.Label31.Text = "Edit Data Izin Usaha"
        '
        'ebtn_batal
        '
        Me.ebtn_batal.Location = New System.Drawing.Point(443, 573)
        Me.ebtn_batal.Name = "ebtn_batal"
        Me.ebtn_batal.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_batal.TabIndex = 54
        Me.ebtn_batal.Text = "Batal"
        Me.ebtn_batal.UseVisualStyleBackColor = True
        '
        'ebtn_simpan
        '
        Me.ebtn_simpan.Location = New System.Drawing.Point(362, 573)
        Me.ebtn_simpan.Name = "ebtn_simpan"
        Me.ebtn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_simpan.TabIndex = 53
        Me.ebtn_simpan.Text = "Simpan"
        Me.ebtn_simpan.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.etxt_id)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.etxt_tgl_pengajuan)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.etxt_alamat_usaha)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.etxt_bidang_usaha)
        Me.Panel1.Controls.Add(Me.etxt_nama_usaha)
        Me.Panel1.Controls.Add(Me.etxt_alamat)
        Me.Panel1.Controls.Add(Me.erbtn_P)
        Me.Panel1.Controls.Add(Me.etxt_tempat_lahir)
        Me.Panel1.Controls.Add(Me.etxt_nama)
        Me.Panel1.Controls.Add(Me.erbtn_L)
        Me.Panel1.Controls.Add(Me.etxt_tgl_lahir)
        Me.Panel1.Controls.Add(Me.ecmb_agama)
        Me.Panel1.Controls.Add(Me.etxt_nik)
        Me.Panel1.Location = New System.Drawing.Point(12, 56)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(506, 511)
        Me.Panel1.TabIndex = 52
        '
        'etxt_id
        '
        Me.etxt_id.AutoSize = True
        Me.etxt_id.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_id.Location = New System.Drawing.Point(27, 0)
        Me.etxt_id.Name = "etxt_id"
        Me.etxt_id.Size = New System.Drawing.Size(22, 16)
        Me.etxt_id.TabIndex = 57
        Me.etxt_id.Text = "no"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(-1, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(30, 16)
        Me.Label12.TabIndex = 56
        Me.Label12.Text = "No :"
        '
        'edit_izin_usaha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(530, 613)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.ebtn_batal)
        Me.Controls.Add(Me.ebtn_simpan)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "edit_izin_usaha"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SIKPD Demulih"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents etxt_tgl_pengajuan As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents etxt_alamat_usaha As System.Windows.Forms.RichTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents etxt_bidang_usaha As System.Windows.Forms.TextBox
    Friend WithEvents etxt_nama_usaha As System.Windows.Forms.TextBox
    Friend WithEvents etxt_alamat As System.Windows.Forms.RichTextBox
    Friend WithEvents erbtn_P As System.Windows.Forms.RadioButton
    Friend WithEvents etxt_tempat_lahir As System.Windows.Forms.TextBox
    Friend WithEvents etxt_nama As System.Windows.Forms.TextBox
    Friend WithEvents erbtn_L As System.Windows.Forms.RadioButton
    Friend WithEvents etxt_tgl_lahir As System.Windows.Forms.DateTimePicker
    Friend WithEvents ecmb_agama As System.Windows.Forms.ComboBox
    Friend WithEvents etxt_nik As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents ebtn_batal As System.Windows.Forms.Button
    Friend WithEvents ebtn_simpan As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents etxt_id As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
End Class
