﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Halaman_Utama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Halaman_Utama))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btn_izinusaha = New System.Windows.Forms.Button()
        Me.btn_pindah = New System.Windows.Forms.Button()
        Me.btn_kematian = New System.Windows.Forms.Button()
        Me.btn_kelahiran = New System.Windows.Forms.Button()
        Me.btn_penduduk = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.LaporanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CetakLaporanDataKelahiranToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CetakLaporanDataKeatianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CetakDataLaporanIzinUsahaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CetakLaporanDataPindahToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.btn_izinusaha)
        Me.Panel1.Controls.Add(Me.btn_pindah)
        Me.Panel1.Controls.Add(Me.btn_kematian)
        Me.Panel1.Controls.Add(Me.btn_kelahiran)
        Me.Panel1.Controls.Add(Me.btn_penduduk)
        Me.Panel1.Location = New System.Drawing.Point(12, 200)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1320, 293)
        Me.Panel1.TabIndex = 0
        '
        'btn_izinusaha
        '
        Me.btn_izinusaha.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_izinusaha.AutoSize = True
        Me.btn_izinusaha.FlatAppearance.BorderSize = 0
        Me.btn_izinusaha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_izinusaha.Image = CType(resources.GetObject("btn_izinusaha.Image"), System.Drawing.Image)
        Me.btn_izinusaha.Location = New System.Drawing.Point(934, 31)
        Me.btn_izinusaha.Name = "btn_izinusaha"
        Me.btn_izinusaha.Size = New System.Drawing.Size(137, 130)
        Me.btn_izinusaha.TabIndex = 4
        Me.btn_izinusaha.UseVisualStyleBackColor = True
        '
        'btn_pindah
        '
        Me.btn_pindah.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_pindah.AutoSize = True
        Me.btn_pindah.FlatAppearance.BorderSize = 0
        Me.btn_pindah.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_pindah.Image = CType(resources.GetObject("btn_pindah.Image"), System.Drawing.Image)
        Me.btn_pindah.Location = New System.Drawing.Point(757, 31)
        Me.btn_pindah.Name = "btn_pindah"
        Me.btn_pindah.Size = New System.Drawing.Size(154, 130)
        Me.btn_pindah.TabIndex = 3
        Me.btn_pindah.UseVisualStyleBackColor = True
        '
        'btn_kematian
        '
        Me.btn_kematian.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_kematian.FlatAppearance.BorderSize = 0
        Me.btn_kematian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_kematian.Image = CType(resources.GetObject("btn_kematian.Image"), System.Drawing.Image)
        Me.btn_kematian.Location = New System.Drawing.Point(576, 31)
        Me.btn_kematian.Name = "btn_kematian"
        Me.btn_kematian.Size = New System.Drawing.Size(159, 130)
        Me.btn_kematian.TabIndex = 2
        Me.btn_kematian.UseVisualStyleBackColor = True
        '
        'btn_kelahiran
        '
        Me.btn_kelahiran.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_kelahiran.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_kelahiran.FlatAppearance.BorderSize = 0
        Me.btn_kelahiran.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_kelahiran.Image = CType(resources.GetObject("btn_kelahiran.Image"), System.Drawing.Image)
        Me.btn_kelahiran.Location = New System.Drawing.Point(415, 31)
        Me.btn_kelahiran.Name = "btn_kelahiran"
        Me.btn_kelahiran.Size = New System.Drawing.Size(143, 130)
        Me.btn_kelahiran.TabIndex = 1
        Me.btn_kelahiran.UseVisualStyleBackColor = True
        '
        'btn_penduduk
        '
        Me.btn_penduduk.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btn_penduduk.AutoSize = True
        Me.btn_penduduk.BackColor = System.Drawing.Color.Transparent
        Me.btn_penduduk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_penduduk.FlatAppearance.BorderSize = 0
        Me.btn_penduduk.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_penduduk.Image = CType(resources.GetObject("btn_penduduk.Image"), System.Drawing.Image)
        Me.btn_penduduk.Location = New System.Drawing.Point(254, 31)
        Me.btn_penduduk.Name = "btn_penduduk"
        Me.btn_penduduk.Size = New System.Drawing.Size(138, 130)
        Me.btn_penduduk.TabIndex = 0
        Me.btn_penduduk.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(613, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(113, 100)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaporanToolStripMenuItem, Me.CetakLaporanDataKelahiranToolStripMenuItem, Me.CetakLaporanDataKeatianToolStripMenuItem, Me.CetakDataLaporanIzinUsahaToolStripMenuItem, Me.CetakLaporanDataPindahToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(235, 114)
        '
        'LaporanToolStripMenuItem
        '
        Me.LaporanToolStripMenuItem.Name = "LaporanToolStripMenuItem"
        Me.LaporanToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.LaporanToolStripMenuItem.Text = "Cetak Laporan Data Penduduk"
        '
        'CetakLaporanDataKelahiranToolStripMenuItem
        '
        Me.CetakLaporanDataKelahiranToolStripMenuItem.Name = "CetakLaporanDataKelahiranToolStripMenuItem"
        Me.CetakLaporanDataKelahiranToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.CetakLaporanDataKelahiranToolStripMenuItem.Text = "Cetak Laporan Data Kelahiran"
        '
        'CetakLaporanDataKeatianToolStripMenuItem
        '
        Me.CetakLaporanDataKeatianToolStripMenuItem.Name = "CetakLaporanDataKeatianToolStripMenuItem"
        Me.CetakLaporanDataKeatianToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.CetakLaporanDataKeatianToolStripMenuItem.Text = "Cetak Laporan Data Keatian"
        '
        'CetakDataLaporanIzinUsahaToolStripMenuItem
        '
        Me.CetakDataLaporanIzinUsahaToolStripMenuItem.Name = "CetakDataLaporanIzinUsahaToolStripMenuItem"
        Me.CetakDataLaporanIzinUsahaToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.CetakDataLaporanIzinUsahaToolStripMenuItem.Text = "Cetak Data Laporan Izin Usaha"
        '
        'CetakLaporanDataPindahToolStripMenuItem
        '
        Me.CetakLaporanDataPindahToolStripMenuItem.Name = "CetakLaporanDataPindahToolStripMenuItem"
        Me.CetakLaporanDataPindahToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.CetakLaporanDataPindahToolStripMenuItem.Text = "Cetak Laporan Data Pindah"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(380, 117)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(624, 37)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "SISTEM INFORMASI KEPENDUDUKAN"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(557, 154)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(230, 31)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "DESA DEMULIH"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(264, 179)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 16)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Data Penduduk"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(424, 179)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(114, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Data Kelahiran"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(597, 179)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 16)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Data Kematian"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(788, 179)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 16)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Data Pindah"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(941, 179)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(122, 16)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Data Izin Usaha"
        '
        'Halaman_Utama
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1344, 525)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Halaman_Utama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SIKPD Demulih"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_izinusaha As System.Windows.Forms.Button
    Friend WithEvents btn_pindah As System.Windows.Forms.Button
    Friend WithEvents btn_kematian As System.Windows.Forms.Button
    Friend WithEvents btn_kelahiran As System.Windows.Forms.Button
    Friend WithEvents btn_penduduk As System.Windows.Forms.Button
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents LaporanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CetakLaporanDataKelahiranToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CetakLaporanDataKeatianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CetakDataLaporanIzinUsahaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CetakLaporanDataPindahToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label

End Class
