﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.DataVisualization.Charting
Imports DevExpress.XtraReports.UI
Public Class Menu_Penduduk
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_penduduk As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Dim DataPenjualan As New Koneksi
    Dim oDataTabelPenjualan2 As New DataTable
    Sub Data_Record()
        tb_penduduk = Proses.ExecuteQuery("SELECT nik, nama,tempat_lahir,tanggal_lahir,alamat,agama,jenis_kelamin,pendidikan,status_perkawinan,pekerjaan,kewarganegaraan,ket, kd from tb_penduduk where ket ='-'")
        DataGridView1.DataSource = tb_penduduk
        DataGridView1.Columns(0).HeaderText = "NIK"
        DataGridView1.Columns(0).Width = 150
        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "ALAMAT"
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).HeaderText = "AGAMA"
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "PENDIDIKAN"
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).HeaderText = "STATUS PERKAWINAN"
        DataGridView1.Columns(8).Width = 100
        DataGridView1.Columns(9).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(9).Width = 100
        DataGridView1.Columns(10).HeaderText = "KEWARGANEGARAAN"
        DataGridView1.Columns(10).Width = 125
        DataGridView1.Columns(11).HeaderText = "KET"
        DataGridView1.Columns(11).Width = 50
        DataGridView1.Columns(12).HeaderText = ""
        DataGridView1.Columns(12).Width = 10
    End Sub

    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        DataGridView1.Rows(e.RowIndex).HeaderCell.Value = CStr(e.RowIndex + 1)
    End Sub

    ' Private Sub Menu_Penduduk_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
    'If MsgBox("Apakah Anda yakin ingin keluar ?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
    ' e.Cancel = False
    'Else
    ' e.Cancel = True
    ' End If
    'End Sub
    Private Sub Menu_Penduduk_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call Data_Chart()
        Call Data_Record()


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        tambah_data_penduduk.ShowDialog()
    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        SQL = "Select * from tb_penduduk " & _
            " where nik like '%" & txtCari.Text & "%' or nama like  '%" & txtCari.Text & "%' or alamat like '%" & txtCari.Text & "%'"

        tb_penduduk.Clear()
        tb_penduduk = Proses.ExecuteQuery(SQL)
        DataGridView1.DataSource = tb_penduduk
        DataGridView1.Columns(0).HeaderText = "NIK"
        DataGridView1.Columns(0).Width = 150
        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "ALAMAT"
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).HeaderText = "AGAMA"
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "PENDIDIKAN"
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).HeaderText = "STATUS PERKAWINAN"
        DataGridView1.Columns(8).Width = 100
        DataGridView1.Columns(9).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(9).Width = 100
        DataGridView1.Columns(10).HeaderText = "KEWARGANEGARAAN"
        DataGridView1.Columns(10).Width = 125
        DataGridView1.Columns(11).HeaderText = "KET"
        DataGridView1.Columns(11).Width = 50
        DataGridView1.Columns(12).HeaderText = ""
        DataGridView1.Columns(12).Width = 10
    End Sub
    Private Sub btncari_Click(sender As Object, e As EventArgs) Handles btncari.Click
        SQL = "Select * from tb_penduduk " & _
          " where nik like '%" & txtCari.Text & "%' or nama like  '%" & txtCari.Text & "%' or alamat like '%" & txtCari.Text & "%'"

        tb_penduduk.Clear()
        tb_penduduk = Proses.ExecuteQuery(SQL)
        DataGridView1.DataSource = tb_penduduk
        DataGridView1.Columns(0).HeaderText = "NIK"
        DataGridView1.Columns(0).Width = 150
        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "ALAMAT"
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).HeaderText = "AGAMA"
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "PENDIDIKAN"
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).HeaderText = "STATUS PERKAWINAN"
        DataGridView1.Columns(8).Width = 100
        DataGridView1.Columns(9).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(9).Width = 100
        DataGridView1.Columns(10).HeaderText = "KEWARGANEGARAAN"
        DataGridView1.Columns(10).Width = 125
        DataGridView1.Columns(11).HeaderText = "KET"
        DataGridView1.Columns(11).Width = 50
        DataGridView1.Columns(12).HeaderText = ""
        DataGridView1.Columns(12).Width = 10
    End Sub

    Private Sub btn_edit_Click(sender As Object, e As EventArgs) Handles btn_edit.Click
        edit_data_penduduk.etxt_nik.Text = DataGridView1.SelectedCells.Item(0).Value
        edit_data_penduduk.etxt_nama.Text = DataGridView1.SelectedCells.Item(1).Value
        edit_data_penduduk.etxt_tempat_lahir.Text = DataGridView1.SelectedCells.Item(2).Value
        edit_data_penduduk.etxt_tgl_lahir.Value = DataGridView1.SelectedCells.Item(3).Value
        edit_data_penduduk.etxt_alamat.Text = DataGridView1.SelectedCells.Item(4).Value
        edit_data_penduduk.ecmb_agama.Text = DataGridView1.SelectedCells.Item(5).Value
        If DataGridView1.SelectedCells.Item(6).Value = "Laki-Laki" Then
            edit_data_penduduk.erbtn_L.Checked = True
        Else
            edit_data_penduduk.erbtn_P.Checked = True
        End If
        edit_data_penduduk.etxt_pendidikan.Text = DataGridView1.SelectedCells.Item(7).Value
        edit_data_penduduk.ecmb_status.Text = DataGridView1.SelectedCells.Item(8).Value
        edit_data_penduduk.etxt_pekerjaan.Text = DataGridView1.SelectedCells.Item(9).Value
        edit_data_penduduk.ecmb_kewarganegaraan.Text = DataGridView1.SelectedCells.Item(10).Value
        edit_data_penduduk.tket.Text = DataGridView1.SelectedCells.Item(11).Value
        edit_data_penduduk.idtxt.text = DataGridView1.SelectedCells.Item(12).Value
        edit_data_penduduk.ShowDialog()
    End Sub


    Sub Data_Chart()
        conn = New MySqlConnection
        conn.ConnectionString =
       "server=localhost;userid=root;password=;database=sikpd"
        Dim READER As MySqlDataReader

        Try
            conn.Open()
            Dim Query As String
            Query = "SELECT COUNT(IF(jenis_kelamin LIKE 'perempuan%',0,NULL)) AS p,COUNT(IF(jenis_kelamin LIKE 'laki-laki%',0,NULL)) AS l FROM tb_penduduk where ket ='-' "
            cd = New MySqlCommand(Query, conn)
            READER = cd.ExecuteReader
            While READER.Read
                Chart1.Series("Laki-Laki").Points.AddXY("Penduduk", READER("l"))
                Chart1.Series("Perempuan").Points.AddXY("Penduduk", READER("p"))
            End While
            conn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try
    End Sub

    Private Sub btn_print_Click(sender As Object, e As EventArgs) Handles btn_print.Click
        loadDataDetail()
        CetakLaporanPenjualan(oDataTabelPenjualan2)
    End Sub
    Sub loadDataDetail()
        oDataTabelPenjualan2.Clear()
        oDataTabelPenjualan2 = DataPenjualan.ExecuteQuery("SELECT nik, nama,tanggal_lahir,agama,alamat,status_perkawinan,ket from tb_penduduk where ket ='-'")

    End Sub
    Private Sub CetakLaporanPenjualan(ByVal oDataTabel As DataTable)


        Dim ReportLapPenjualan As New lap_penduduk
        Dim Tool As ReportPrintTool = New ReportPrintTool(ReportLapPenjualan)
        Dim oDataSet As New DataSet
        Dim oDataSet2 As New DataSet
        Dim t As New DateTimePicker
        Dim tp As New Date







        Try
            If oDataSet.Tables.Count <> 0 Then
                oDataSet.Tables.Remove("Table1")
            End If
            oDataSet.Tables.Add(oDataTabelPenjualan2.Copy)

            ReportLapPenjualan.DataSource = oDataSet
            ReportLapPenjualan.DataMember = "Table1"

            ReportLapPenjualan.nik.DataBindings.Add("Text", Nothing, "nik")
            ReportLapPenjualan.nama.DataBindings.Add("Text", Nothing, "nama")


            ReportLapPenjualan.tgl.DataBindings.Add("Text", Nothing, "tanggal_lahir", "{0:dd-MM-yyyy}")

            ReportLapPenjualan.alamat.DataBindings.Add("Text", Nothing, "alamat")
            ReportLapPenjualan.agama.DataBindings.Add("Text", Nothing, "agama")
            ReportLapPenjualan.status.DataBindings.Add("Text", Nothing, "status_perkawinan")
            ReportLapPenjualan.ket.DataBindings.Add("Text", Nothing, "ket")

            Tool.ShowPreview()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Halaman_Utama.Show()
        Me.Close()
    End Sub
End Class