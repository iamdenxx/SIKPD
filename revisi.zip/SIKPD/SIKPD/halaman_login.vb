﻿Imports System.Data
Imports MySql.Data.MySqlClient
Public Class halaman_login
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim qty As Integer

   

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        form_login.ShowDialog()
    End Sub
End Class