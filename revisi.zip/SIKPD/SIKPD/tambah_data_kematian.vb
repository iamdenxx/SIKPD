﻿Imports MySql.Data.MySqlClient
Public Class tambah_data_kematian
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim no As DataTable
    Dim tb_kematian As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim nomerbaru As String
    Dim nomerterakhir As String
    Dim nourutbaru As Integer
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Sub Clear()
        txt_nama.Text = ""
        txt_tempat_lahir.Text = ""
        txt_tgl.Text = Date.Now
        txt_alamat.Text = ""
        cmb_agama.Text = ""
        txt_tempat_meninggal.Text = ""
        txt_tgl_meninggal.Text = Date.Now
    End Sub
    Sub Data_Record()
        tb_kematian = Proses.ExecuteQuery("Select nik,nama,tempat_lahir,tgl_lahir,jenis_kelamin,alamat ,agama,tempat_meninggal,tanggal_kematian From tb_kematian order by tgl DESC")
        Menu_Data_Kematian.DataGridView1.DataSource = tb_kematian
        Menu_Data_Kematian.DataGridView1.Columns(0).HeaderText = "NIK"
        Menu_Data_Kematian.DataGridView1.Columns(0).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(1).HeaderText = "NAMA"
        Menu_Data_Kematian.DataGridView1.Columns(1).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        Menu_Data_Kematian.DataGridView1.Columns(2).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        Menu_Data_Kematian.DataGridView1.Columns(3).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        Menu_Data_Kematian.DataGridView1.Columns(4).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(5).HeaderText = "ALAMAT"
        Menu_Data_Kematian.DataGridView1.Columns(5).Width = 200
        Menu_Data_Kematian.DataGridView1.Columns(6).HeaderText = "AGAMA"
        Menu_Data_Kematian.DataGridView1.Columns(6).Width = 100
        Menu_Data_Kematian.DataGridView1.Columns(7).HeaderText = "TEMPAT MENINGGAL"
        Menu_Data_Kematian.DataGridView1.Columns(7).Width = 200
        Menu_Data_Kematian.DataGridView1.Columns(8).HeaderText = "TGL MENINGGAL"
        Menu_Data_Kematian.DataGridView1.Columns(8).Width = 100
    End Sub
   
    Private Sub btn_simpan_Click(sender As Object, e As EventArgs) Handles btn_simpan.Click
        Dim jk As New TextBox
        Dim ket As String

        ket = "meninggal"
        If (rbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If
        If txt_nik.Text = "" Then txt_nik.Focus() : Exit Sub
        If txt_nama.Text = "" Then txt_nama.Focus() : Exit Sub
        If txt_alamat.Text = "" Then txt_alamat.Focus() : Exit Sub
        If cmb_agama.Text = "" Then cmb_agama.Focus() : Exit Sub
        If txt_tempat_meninggal.Text = "" Then txt_tempat_meninggal.Focus() : Exit Sub
        SQL = "Insert Into tb_kematian (nik,nama,tempat_lahir,tgl_lahir,jenis_kelamin, alamat, agama, tempat_meninggal,tanggal_kematian,tgl) Values ('" & txt_nik.Text & "','" & txt_nama.Text & "','" & txt_tempat_lahir.Text & "','" & Format(txt_tgl.Value, "yyyy-MM-dd") & "','" & jk.Text & "','" & txt_alamat.Text & "','" & cmb_agama.Text & "','" & txt_tempat_meninggal.Text & "','" & Format(txt_tgl_meninggal.Value, "yyyy-MM-dd") & "','" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "')"
        Proses.ExecuteNonQuery(SQL)

        SQL = "update tb_penduduk set ket = '" & ket & "' where nik = '" & txt_nik.Text & "'"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Ditambahkan", "Success Message", MessageBoxButtons.OK)
        Dim msg As DialogResult
        msg = MessageBox.Show("Ada Data yang akan diinputkan lagi ?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If msg = Windows.Forms.DialogResult.No Then
            Call Data_Chart()
            Call Clear()
            Call Data_Record()
            Me.Close()
        Else
            Call Clear()
        End If

    End Sub
    Private Sub txt_nik_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_nik.KeyPress
        If (e.KeyChar = Chr(13)) Then
            conn = New MySqlConnection("server=localhost; user id=root; password =; database=sikpd;")
            conn.Open()
            Try
                cd = New MySqlCommand("select * from tb_penduduk where nik ='" & txt_nik.Text & "'", conn)
                rd = cd.ExecuteReader()
                rd.Read()
                If rd.HasRows Then
                    txt_nama.Text = rd.Item("nama")
                    txt_tgl.Value = rd.Item("tanggal_lahir")
                    cmb_agama.Text = rd.Item("agama")
                    txt_tempat_lahir.Text = rd.Item("tempat_lahir")
                    txt_alamat.Text = rd.Item("alamat")
                    txt_tempat_meninggal.Focus()
                    If rd.Item("jenis_kelamin") = "Laki-Laki" Then
                        rbtn_L.Checked = True
                    Else
                        rbtn_P.Checked = True
                    End If
                End If

            Catch ex As Exception

                MessageBox.Show("Koneksi Gagal !!!, karena " & ex.Message)
            End Try
            conn.Close()
        End If
    End Sub

    Private Sub btn_batal_Click(sender As Object, e As EventArgs) Handles btn_batal.Click
        Call Clear()
        Me.Close()
    End Sub
    Sub Data_Chart()
        conn = New MySqlConnection
        conn.ConnectionString =
       "server=localhost;userid=root;password=;database=sikpd"
        Dim READER As MySqlDataReader

        Try
            conn.Open()
            Dim Query As String
            Query = "SELECT DATE_FORMAT(tgl,'%M') as bln, COUNT(*)AS jmlh FROM tb_kematian where YEAR(tgl)='" & Label3.Text & "' GROUP BY MONTH(tgl)"
            cd = New MySqlCommand(Query, conn)
            READER = cd.ExecuteReader
            While READER.Read

                Menu_Data_Kematian.Chart1.Series("Data Kematian").Points.AddXY(READER("bln"), READER("jmlh"))


            End While
            conn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try
    End Sub

End Class