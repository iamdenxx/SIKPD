﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.DataVisualization.Charting
Imports DevExpress.XtraReports.UI
Public Class Menu_Data_Kelahiran
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_kelahiran As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Dim DataPenjualan As New Koneksi
    Dim oDataTabelPenjualan2 As New DataTable
    Sub Data_Record()
        tb_kelahiran = Proses.ExecuteQuery("Select id_lahir, nama, tempat_lahir, tanggal_lahir, jenis_kelamin, agama, nik_ayah,nama_ayah, tgl_lahir_ayah,umur_ayah, pekerjaan_ayah, alamat_ayah,nik_ibu,nama_ibu, tgl_lahir_ibu,umur_ibu, pekerjaan_ibu, alamat_ibu From tb_kelahiran order by id_lahir DESC")
        DataGridView1.DataSource = tb_kelahiran
        DataGridView1.Columns(0).HeaderText = "ID"
        DataGridView1.Columns(0).Width = 100
      
        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).HeaderText = "AGAMA"
        DataGridView1.Columns(5).Width = 100

        DataGridView1.Columns(6).HeaderText = "NIK AYAH"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "NAMA AYAH"
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(8).Width = 200
        DataGridView1.Columns(9).HeaderText = "UMUR"
        DataGridView1.Columns(9).Width = 100
        DataGridView1.Columns(10).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(10).Width = 100
        DataGridView1.Columns(11).HeaderText = "ALAMAT"
        DataGridView1.Columns(11).Width = 200

        DataGridView1.Columns(12).HeaderText = "NIK IBU"
        DataGridView1.Columns(12).Width = 100
        DataGridView1.Columns(13).HeaderText = "NAMA IBU"
        DataGridView1.Columns(13).Width = 100
        DataGridView1.Columns(14).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(14).Width = 200
        DataGridView1.Columns(15).HeaderText = "UMUR"
        DataGridView1.Columns(15).Width = 100
        DataGridView1.Columns(16).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(16).Width = 100
        DataGridView1.Columns(17).HeaderText = "ALAMAT"
        DataGridView1.Columns(17).Width = 200
       
    End Sub

    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        DataGridView1.Rows(e.RowIndex).HeaderCell.Value = CStr(e.RowIndex + 1)
    End Sub

  

    Private Sub btn_tambah_Click(sender As Object, e As EventArgs) Handles btn_tambah.Click
        tambah_data_kelahiran.ShowDialog()
    End Sub

    Private Sub btn_edit_Click(sender As Object, e As EventArgs) Handles btn_edit.Click
        edit_data_kelahiran.etxt_id.Text = DataGridView1.SelectedCells.Item(0).Value

        edit_data_kelahiran.etxt_nama.Text = DataGridView1.SelectedCells.Item(1).Value
        edit_data_kelahiran.etxt_tempat_lahir.Text = DataGridView1.SelectedCells.Item(2).Value
        edit_data_kelahiran.etxt_tgl_lahir.Text = DataGridView1.SelectedCells.Item(3).Value
        If DataGridView1.SelectedCells.Item(4).Value = "Laki-Laki" Then
            edit_data_kelahiran.erbtn_L.Checked = True
        Else
            edit_data_kelahiran.erbtn_P.Checked = True

        End If
        edit_data_kelahiran.ecmb_agama.Text = DataGridView1.SelectedCells.Item(5).Value
        edit_data_kelahiran.ecmb_nik_ayah.Text = DataGridView1.SelectedCells.Item(6).Value
        edit_data_kelahiran.etxt_nama_ayah.Text = DataGridView1.SelectedCells.Item(7).Value
        edit_data_kelahiran.etxt_tgl_lahir_ayah.Value = DataGridView1.SelectedCells.Item(8).Value
        edit_data_kelahiran.etxt_umur_ayah.Text = DataGridView1.SelectedCells.Item(9).Value
        edit_data_kelahiran.etxt_pekerjaan_ayah.Text = DataGridView1.SelectedCells.Item(10).Value
        edit_data_kelahiran.etxt_alamat_ayah.Text = DataGridView1.SelectedCells.Item(11).Value

        edit_data_kelahiran.ecmb_nik_ibu.Text = DataGridView1.SelectedCells.Item(12).Value
        edit_data_kelahiran.etxt_nama_ibu.Text = DataGridView1.SelectedCells.Item(13).Value
        edit_data_kelahiran.etxt_tgl_lahir.Value = DataGridView1.SelectedCells.Item(14).Value
        edit_data_kelahiran.etxt_umur_ibu.Text = DataGridView1.SelectedCells.Item(15).Value
        edit_data_kelahiran.etxt_pekerjaan_ibu.Text = DataGridView1.SelectedCells.Item(16).Value
        edit_data_kelahiran.etxt_alamat_ibu.Text = DataGridView1.SelectedCells.Item(17).Value

        edit_data_kelahiran.ShowDialog()
    End Sub

   


    Private Sub Menu_Data_Kelahiran_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call Data_Chart()
        Call Data_Record()
        
        Label2.Text = Format(Now, "MMMM")
        Label3.Text = Format(Now, "yyyy")
        
    End Sub

    Private Sub btncari_Click(sender As Object, e As EventArgs) Handles btncari.Click
        SQL = "Select * from tb_kelahiran " & _
          " where nama like  '%" & txtCari.Text & "%' or tanggal_lahir like '%" & txtCari.Text & "%'"

        tb_kelahiran.Clear()
        tb_kelahiran = Proses.ExecuteQuery(SQL)
        DataGridView1.DataSource = tb_kelahiran
        DataGridView1.Columns(0).HeaderText = "ID"
        DataGridView1.Columns(0).Width = 100

        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).HeaderText = "AGAMA"
        DataGridView1.Columns(5).Width = 100

        DataGridView1.Columns(6).HeaderText = "NIK AYAH"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "NAMA AYAH"
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(8).Width = 200
        DataGridView1.Columns(9).HeaderText = "UMUR"
        DataGridView1.Columns(9).Width = 100
        DataGridView1.Columns(10).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(10).Width = 100
        DataGridView1.Columns(11).HeaderText = "ALAMAT"
        DataGridView1.Columns(11).Width = 200

        DataGridView1.Columns(12).HeaderText = "NIK IBU"
        DataGridView1.Columns(12).Width = 100
        DataGridView1.Columns(13).HeaderText = "NAMA IBU"
        DataGridView1.Columns(13).Width = 100
        DataGridView1.Columns(14).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(14).Width = 200
        DataGridView1.Columns(15).HeaderText = "UMUR"
        DataGridView1.Columns(15).Width = 100
        DataGridView1.Columns(16).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(16).Width = 100
        DataGridView1.Columns(17).HeaderText = "ALAMAT"
        DataGridView1.Columns(17).Width = 200

    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        SQL = "Select * from tb_kelahiran " & _
         " where nama like  '%" & txtCari.Text & "%' or tanggal_lahir like '%" & txtCari.Text & "%'"

        tb_kelahiran.Clear()
        tb_kelahiran = Proses.ExecuteQuery(SQL)
        DataGridView1.DataSource = tb_kelahiran
        DataGridView1.Columns(0).HeaderText = "ID"
        DataGridView1.Columns(0).Width = 100

        DataGridView1.Columns(1).HeaderText = "NAMA"
        DataGridView1.Columns(1).Width = 150
        DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).HeaderText = "AGAMA"
        DataGridView1.Columns(5).Width = 100

        DataGridView1.Columns(6).HeaderText = "NIK AYAH"
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).HeaderText = "NAMA AYAH"
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(8).Width = 200
        DataGridView1.Columns(9).HeaderText = "UMUR"
        DataGridView1.Columns(9).Width = 100
        DataGridView1.Columns(10).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(10).Width = 100
        DataGridView1.Columns(11).HeaderText = "ALAMAT"
        DataGridView1.Columns(11).Width = 200

        DataGridView1.Columns(12).HeaderText = "NIK IBU"
        DataGridView1.Columns(12).Width = 100
        DataGridView1.Columns(13).HeaderText = "NAMA IBU"
        DataGridView1.Columns(13).Width = 100
        DataGridView1.Columns(14).HeaderText = "TGL LAHIR"
        DataGridView1.Columns(14).Width = 200
        DataGridView1.Columns(15).HeaderText = "UMUR"
        DataGridView1.Columns(15).Width = 100
        DataGridView1.Columns(16).HeaderText = "PEKERJAAN"
        DataGridView1.Columns(16).Width = 100
        DataGridView1.Columns(17).HeaderText = "ALAMAT"
        DataGridView1.Columns(17).Width = 200
    End Sub

    Sub Data_Chart()
        conn = New MySqlConnection
        conn.ConnectionString =
       "server=localhost;userid=root;password=;database=sikpd"
        Dim READER As MySqlDataReader
        

        Try
            conn.Open()
            Dim Query As String
            Query = "SELECT COUNT(IF(jenis_kelamin LIKE 'perempuan%',0,NULL)) AS p,COUNT(IF(jenis_kelamin LIKE 'laki-laki%',0,NULL)) AS l,DATE_FORMAT(tgl,'%M') AS bln FROM tb_kelahiran where YEAR(tgl)='" & Format(Now, "yyyy") & "' GROUP BY MONTH(tgl)"
            cd = New MySqlCommand(Query, conn)
            READER = cd.ExecuteReader

            While READER.Read

                Chart1.Series("Laki-Laki").Points.AddXY(READER("bln"), READER("l"))
                Chart1.Series("Perempuan").Points.AddXY(READER("bln"), READER("p"))
               

            End While
            conn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try

    End Sub

    Private Sub btn_cetak_Click(sender As Object, e As EventArgs) Handles btn_cetak.Click
        loadDataDetail()
        CetakLaporanPenjualan(oDataTabelPenjualan2)
    End Sub
    Sub loadDataDetail()
        oDataTabelPenjualan2.Clear()
        oDataTabelPenjualan2 = DataPenjualan.ExecuteQuery("SELECT * from tb_kelahiran WHERE id_lahir = '" & DataGridView1.SelectedCells.Item(0).Value & "'")

    End Sub
    Private Sub CetakLaporanPenjualan(ByVal oDataTabel As DataTable)


        Dim ReportLapPenjualan As New lap_kelahiran
        Dim Tool As ReportPrintTool = New ReportPrintTool(ReportLapPenjualan)
        Dim oDataSet As New DataSet
        Dim oDataSet2 As New DataSet
        Dim t As New TextBox
        Dim tp As New TextBox

        tp.Text = Format(DataGridView1.SelectedCells.Item(4).Value, "dd - MM - yyyy")





        Try
            If oDataSet.Tables.Count <> 0 Then
                oDataSet.Tables.Remove("Table1")
            End If
            oDataSet.Tables.Add(oDataTabelPenjualan2.Copy)

            ReportLapPenjualan.DataSource = oDataSet
            ReportLapPenjualan.DataMember = "Table1"

            ReportLapPenjualan.nama.DataBindings.Add("Text", Nothing, "nama")
            ReportLapPenjualan.jk.DataBindings.Add("Text", Nothing, "jenis_kelamin")
            ReportLapPenjualan.tempat.DataBindings.Add("Text", Nothing, "tempat_lahir")
            ReportLapPenjualan.tgl.Text = tp.Text
            ReportLapPenjualan.tgl1.Text = tp.Text
            ReportLapPenjualan.agm.DataBindings.Add("Text", Nothing, "agama")
            ReportLapPenjualan.alamat.DataBindings.Add("Text", Nothing, "alamat_ayah")
            ReportLapPenjualan.tmp1.DataBindings.Add("Text", Nothing, "tempat_lahir")

            Tool.ShowPreview()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Halaman_Utama.Show()
        Me.Close()
    End Sub
End Class