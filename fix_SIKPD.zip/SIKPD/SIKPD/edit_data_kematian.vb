﻿Imports MySql.Data.MySqlClient
Public Class edit_data_kematian
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_kematian As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Sub Data_Record()
        tb_kematian = Proses.ExecuteQuery("Select nik,nama,tempat_lahir,tgl_lahir,jenis_kelamin,alamat, agama,tempat_meninggal,tanggal_kematian From tb_kematian order by tgl DESC")
        Menu_Data_Kematian.DataGridView1.DataSource = tb_kematian
        Menu_Data_Kematian.DataGridView1.Columns(0).HeaderText = "NIK"
        Menu_Data_Kematian.DataGridView1.Columns(0).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(1).HeaderText = "NAMA"
        Menu_Data_Kematian.DataGridView1.Columns(1).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        Menu_Data_Kematian.DataGridView1.Columns(2).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        Menu_Data_Kematian.DataGridView1.Columns(3).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(4).HeaderText = "JENIS KELAMIN"
        Menu_Data_Kematian.DataGridView1.Columns(4).Width = 150
        Menu_Data_Kematian.DataGridView1.Columns(5).HeaderText = "ALAMAT"
        Menu_Data_Kematian.DataGridView1.Columns(5).Width = 200
        Menu_Data_Kematian.DataGridView1.Columns(6).HeaderText = "AGAMA"
        Menu_Data_Kematian.DataGridView1.Columns(6).Width = 100
        Menu_Data_Kematian.DataGridView1.Columns(7).HeaderText = "TEMPAT MENINGGAL"
        Menu_Data_Kematian.DataGridView1.Columns(7).Width = 200
        Menu_Data_Kematian.DataGridView1.Columns(8).HeaderText = "TGL MENINGGAL"
        Menu_Data_Kematian.DataGridView1.Columns(8).Width = 100
    End Sub
    Sub Clear()
        etxt_nama.Text = ""
        etxt_tempat_lahir.Text = ""
        etxt_tgl.Value = Date.Now
        etxt_tgl_meninggal.Value = Date.Now
        etxt_tempat_meninggal.Text = ""
        ecmb_agama.Text = ""
        etxt_tempat_lahir.Text = ""
        etxt_alamat.Text = ""
    End Sub

    Private Sub ebtn_simpan_Click(sender As Object, e As EventArgs) Handles ebtn_simpan.Click
        Dim jk As New TextBox
        If (erbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If
        If etxt_nik.Text = "" Then etxt_nik.Focus() : Exit Sub
        If etxt_tempat_lahir.Text = "" Then etxt_tempat_lahir.Focus() : Exit Sub
        If etxt_alamat.Text = "" Then etxt_alamat.Focus() : Exit Sub
        If etxt_tempat_meninggal.Text = "" Then etxt_tempat_meninggal.Focus() : Exit Sub
        SQL = "update tb_kematian set nik = '" & etxt_nik.Text & "', nama = '" & etxt_nama.Text & "', tempat_lahir = '" & etxt_tempat_lahir.Text & "',tgl_lahir = '" & Format(etxt_tgl.Value, "yyyy-MM-dd") & "' , jenis_kelamin = '" & jk.Text & "',alamat = '" & etxt_alamat.Text & "',agama = '" & ecmb_agama.Text & "',tempat_meninggal = '" & etxt_tempat_meninggal.Text & "',tanggal_kematian = '" & Format(etxt_tgl_meninggal.Value, "yyyy-MM-dd") & "' where nik='" & etxt_nik.Text & "'"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Disimpan", "Success Message", MessageBoxButtons.OK)
        Me.Close()
        Call Data_Record()
    End Sub

    Private Sub ebtn_batal_Click(sender As Object, e As EventArgs) Handles ebtn_batal.Click
        Call Clear()
        Me.Close()
    End Sub
End Class