﻿Imports System.Data
Imports MySql.Data.MySqlClient
Public Class form_login
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim qty As Integer


    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        conn = New MySqlConnection("server=localhost; user id=root; password =; database=sikpd;")
        conn.Open()
        Try

        Catch ex As Exception

        End Try
        Try
            If t_user.Text = "" Or t_pwd.Text = "" Then
                MsgBox("username dan password masih kosong !")
            Else
                cd = New MySqlCommand("select * from tb_login WHERE username ='" & t_user.Text & "' AND password ='" & t_pwd.Text & "'", conn)
                rd = cd.ExecuteReader()
                rd.Read()
                If rd.HasRows Then

                  

                    Halaman_Utama.Show()

                    halaman_login.Close()
                    Me.Close()



                Else
                    MsgBox("Username atau Password Salah !", MsgBoxStyle.Critical)
                    t_user.Focus()
                    t_user.Text = ""
                    t_pwd.Text = ""
                End If
            End If

        Catch ex As Exception
        End Try
    End Sub

   
    Private Sub t_pwd_Click(sender As Object, e As EventArgs) Handles t_pwd.Click
        t_pwd.UseSystemPasswordChar = True
    End Sub

    Private Sub t_pwd_KeyPress(sender As Object, e As KeyPressEventArgs) Handles t_pwd.KeyPress
        If Asc(e.KeyChar) = 13 Then
            btn_login.Focus()
        End If
    End Sub

    Private Sub t_user_KeyPress(sender As Object, e As KeyPressEventArgs) Handles t_user.KeyPress
        If Asc(e.KeyChar) = 13 Then
            t_pwd.Focus()
            t_pwd.Text = ""
            t_pwd.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btn_batal_Click(sender As Object, e As EventArgs) Handles btn_batal.Click
        Me.Close()
        t_user.Text = ""
        t_pwd.Text = ""
    End Sub
End Class