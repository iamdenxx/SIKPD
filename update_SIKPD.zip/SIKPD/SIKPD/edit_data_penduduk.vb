﻿Imports MySql.Data.MySqlClient
Public Class edit_data_penduduk
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_penduduk As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Sub Data_Record()
        tb_penduduk = Proses.ExecuteQuery("SELECT nik, nama,tempat_lahir,tanggal_lahir,alamat,agama,jenis_kelamin,pendidikan,status_perkawinan,pekerjaan,kewarganegaraan,ket,kd from tb_penduduk where ket ='-'")
        Menu_Penduduk.DataGridView1.DataSource = tb_penduduk
        Menu_Penduduk.DataGridView1.Columns(0).HeaderText = "NIK"
        Menu_Penduduk.DataGridView1.Columns(0).Width = 150
        Menu_Penduduk.DataGridView1.Columns(1).HeaderText = "NAMA"
        Menu_Penduduk.DataGridView1.Columns(1).Width = 150
        Menu_Penduduk.DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        Menu_Penduduk.DataGridView1.Columns(2).Width = 150
        Menu_Penduduk.DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        Menu_Penduduk.DataGridView1.Columns(3).Width = 150
        Menu_Penduduk.DataGridView1.Columns(4).HeaderText = "ALAMAT"
        Menu_Penduduk.DataGridView1.Columns(4).Width = 150
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "AGAMA"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
        Menu_Penduduk.DataGridView1.Columns(6).HeaderText = "JENIS KELAMIN"
        Menu_Penduduk.DataGridView1.Columns(6).Width = 100
        Menu_Penduduk.DataGridView1.Columns(7).HeaderText = "PENDIDIKAN"
        Menu_Penduduk.DataGridView1.Columns(7).Width = 100
        Menu_Penduduk.DataGridView1.Columns(8).HeaderText = "STATUS PERKAWINAN"
        Menu_Penduduk.DataGridView1.Columns(8).Width = 100
        Menu_Penduduk.DataGridView1.Columns(9).HeaderText = "PEKERJAAN"
        Menu_Penduduk.DataGridView1.Columns(9).Width = 100
        Menu_Penduduk.DataGridView1.Columns(10).HeaderText = "KEWARGANEGARAAN"
        Menu_Penduduk.DataGridView1.Columns(10).Width = 100
        Menu_Penduduk.DataGridView1.Columns(11).HeaderText = "KET"
        Menu_Penduduk.DataGridView1.Columns(11).Width = 100
        Menu_Penduduk.DataGridView1.Columns(12).HeaderText = ""
        Menu_Penduduk.DataGridView1.Columns(12).Width = 10
    End Sub
    Sub Clear()
        etxt_nik.Text = ""
        etxt_nama.Text = ""
        etxt_alamat.Text = ""
        etxt_tempat_lahir.Text = ""
        erbtn_L.Checked = False
        erbtn_P.Checked = False
        etxt_pekerjaan.Text = ""
        etxt_pendidikan.Text = ""
        etxt_tgl_lahir.Value = Date.Now
        ecmb_agama.Text = ""
        ecmb_kewarganegaraan.Text = ""
        ecmb_status.Text = ""
    End Sub
    Private Sub ebtn_simpan_Click(sender As Object, e As EventArgs) Handles ebtn_simpan.Click
        Dim jk As New TextBox
        If (erbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If
        If etxt_nik.Text = "" Then etxt_nik.Focus() : Exit Sub
        If etxt_tempat_lahir.Text = "" Then etxt_tempat_lahir.Focus() : Exit Sub
        If etxt_alamat.Text = "" Then etxt_alamat.Focus() : Exit Sub
        If etxt_pekerjaan.Text = "" Then etxt_pekerjaan.Focus() : Exit Sub
        If etxt_pendidikan.Text = "" Then etxt_pendidikan.Focus() : Exit Sub
        If ecmb_kewarganegaraan.Text = "" Then ecmb_kewarganegaraan.Focus() : Exit Sub
        If tket.Text = "-" Then
            SQL = "delete from tb_kematian where nik = '" & etxt_nik.Text & "'"
            Proses.ExecuteNonQuery(SQL)
        End If
        SQL = "update tb_penduduk set nik = '" & etxt_nik.Text & "', nama = '" & etxt_nama.Text & "', tempat_lahir = '" & etxt_tempat_lahir.Text & "',tanggal_lahir = '" & Format(etxt_tgl_lahir.Value, "yyyy-MM-dd") & "' , alamat = '" & etxt_alamat.Text & "',agama = '" & ecmb_agama.Text & "',jenis_kelamin = '" & jk.Text & "',pendidikan = '" & etxt_pendidikan.Text & "',status_perkawinan = '" & ecmb_status.Text & "',pekerjaan= '" & etxt_pekerjaan.Text & "',kewarganegaraan = '" & ecmb_kewarganegaraan.Text & "',ket = '" & tket.Text & "' where kd='" & idtxt.Text & "'"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Disimpan", "Success Message", MessageBoxButtons.OK)
        Me.Close()
        Call Data_Record()
    End Sub

    Private Sub ebtn_batal_Click(sender As Object, e As EventArgs) Handles ebtn_batal.Click
        Call Clear()
        Me.Close()
    End Sub
End Class