﻿Imports MySql.Data.MySqlClient
Public Class edit_data_kelahiran
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_kelahiran As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Sub Clear()
        etxt_nik.Text = ""
        etxt_nama.Text = ""
        etxt_tgl_lahir.Value = Date.Now
        etxt_tempat_lahir.Text = ""
        ecmb_agama.Text = ""
        etxt_nik_ayah.Text = ""
        etxt_nama_ayah.Text = ""
        etxt_tgl_lahir_ayah.Value = Date.Now
        etxt_umur_ayah.Text = ""

        etxt_pekerjaan_ayah.Text = ""
        etxt_alamat_ayah.Text = ""
        etxt_nik_ibu.Text = ""
        etxt_nama_ibu.Text = ""
        etxt_tgl_lahir_ibu.Value = Date.Now
        etxt_umur_ibu.Text = ""

        etxt_pekerjaan_ibu.Text = ""
        etxt_alamat_ibu.Text = ""
       
    End Sub
    
    Private Sub ebtn_batal_Click(sender As Object, e As EventArgs) Handles ebtn_batal.Click
        Call Clear()
        Me.Close()
    End Sub

    Private Sub ebtn_simpan_Click(sender As Object, e As EventArgs) Handles ebtn_simpan.Click
        Dim jk As New TextBox
        If (erbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If
        If etxt_nik.Text = "" Then etxt_nik.Focus() : Exit Sub
        If etxt_nik_ayah.Text = "" Then etxt_nik_ayah.Focus() : Exit Sub
        If etxt_nik_ibu.Text = "" Then etxt_nik_ibu.Focus() : Exit Sub
        If ecmb_agama.Text = "" Then ecmb_agama.Focus() : Exit Sub
        
        SQL = "update tb_kelahiran set nik = '" & etxt_nik.Text & "', nama = '" & etxt_nama.Text & "', tempat_lahir = '" & etxt_tempat_lahir.Text & "',tanggal_lahir = '" & Format(etxt_tgl_lahir.Value, "yyyy-MM-dd") & "',jenis_kelamin = '" & jk.Text & "' ,agama = '" & ecmb_agama.Text & "',nik_ayah = '" & etxt_nik_ayah.Text & "',nama_ayah = '" & etxt_nama_ayah.Text & "',tgl_lahir_ayah= '" & Format(etxt_tgl_lahir_ayah.Value, "yyyy-MM-dd") & "', umur_ayah='" & etxt_umur_ayah.Text & "',pekerjaan_ayah='" & etxt_pekerjaan_ayah.Text & "',alamat_ayah='" & etxt_alamat_ayah.Text & "',nik_ibu = '" & etxt_nik_ibu.Text & "',nama_ibu = '" & etxt_nama_ibu.Text & "',tgl_lahir_ibu= '" & Format(etxt_tgl_lahir_ibu.Value, "yyyy-MM-dd") & "', umur_ibu='" & etxt_umur_ibu.Text & "',pekerjaan_ibu='" & etxt_pekerjaan_ibu.Text & "',alamat_ibu='" & etxt_alamat_ibu.Text & "'where id_lahir='" & etxt_id.Text & "'"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Disimpan", "Success Message", MessageBoxButtons.OK)
        Call Data_Chart()
        Call Data_Record()
        Me.Close()
    End Sub

    Sub Data_Chart()
        conn = New MySqlConnection
        conn.ConnectionString =
       "server=localhost;userid=root;password=;database=sikpd"
        Dim READER As MySqlDataReader


        Try
            conn.Open()
            Dim Query As String
            Query = "SELECT COUNT(IF(jenis_kelamin LIKE 'perempuan%',0,NULL)) AS p,COUNT(IF(jenis_kelamin LIKE 'laki-laki%',0,NULL)) AS l,DATE_FORMAT(tgl,'%M') AS bln FROM tb_kelahiran where YEAR(tgl)='" & Format(Now, "yyyy") & "' GROUP BY MONTH(tgl)"
            cd = New MySqlCommand(Query, conn)
            READER = cd.ExecuteReader

            While READER.Read

                Menu_Data_Kelahiran.Chart1.Series("Laki-Laki").Points.AddXY(READER("bln"), READER("l"))
                Menu_Data_Kelahiran.Chart1.Series("Perempuan").Points.AddXY(READER("bln"), READER("p"))

            End While
            conn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try

    End Sub

    Sub Data_Record()
        tb_kelahiran = Proses.ExecuteQuery("Select id_lahir, nik, nama, tempat_lahir, tanggal_lahir, jenis_kelamin,agama, nik_ayah,nama_ayah, tgl_lahir_ayah,umur_ayah, pekerjaan_ayah, alamat_ayah,nik_ibu,nama_ibu, tgl_lahir_ibu,umur_ibu, pekerjaan_ibu, alamat_ibu From tb_kelahiran order by id_lahir DESC")
        Menu_Data_Kelahiran.DataGridView1.DataSource = tb_kelahiran
        Menu_Data_Kelahiran.DataGridView1.Columns(0).HeaderText = "ID"
        Menu_Data_Kelahiran.DataGridView1.Columns(0).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(1).HeaderText = "NIK"
        Menu_Data_Kelahiran.DataGridView1.Columns(1).Width = 150
        Menu_Data_Kelahiran.DataGridView1.Columns(2).HeaderText = "NAMA"
        Menu_Data_Kelahiran.DataGridView1.Columns(2).Width = 150
        Menu_Data_Kelahiran.DataGridView1.Columns(3).HeaderText = "TEMPAT LAHIR"
        Menu_Data_Kelahiran.DataGridView1.Columns(3).Width = 150
        Menu_Data_Kelahiran.DataGridView1.Columns(4).HeaderText = "TGL LAHIR"
        Menu_Data_Kelahiran.DataGridView1.Columns(4).Width = 150
        Menu_Data_Kelahiran.DataGridView1.Columns(5).HeaderText = "JENIS KELAMIN"
        Menu_Data_Kelahiran.DataGridView1.Columns(5).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(6).HeaderText = "AGAMA"
        Menu_Data_Kelahiran.DataGridView1.Columns(6).Width = 100

        Menu_Data_Kelahiran.DataGridView1.Columns(7).HeaderText = "NIK AYAH"
        Menu_Data_Kelahiran.DataGridView1.Columns(7).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(8).HeaderText = "NAMA AYAH"
        Menu_Data_Kelahiran.DataGridView1.Columns(8).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(9).HeaderText = "TGL LAHIR"
        Menu_Data_Kelahiran.DataGridView1.Columns(9).Width = 200
        Menu_Data_Kelahiran.DataGridView1.Columns(10).HeaderText = "UMUR"
        Menu_Data_Kelahiran.DataGridView1.Columns(10).Width = 100

        Menu_Data_Kelahiran.DataGridView1.Columns(11).HeaderText = "PEKERJAAN"
        Menu_Data_Kelahiran.DataGridView1.Columns(11).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(12).HeaderText = "ALAMAT"
        Menu_Data_Kelahiran.DataGridView1.Columns(12).Width = 200
        Menu_Data_Kelahiran.DataGridView1.Columns(13).HeaderText = "NIK IBU"
        Menu_Data_Kelahiran.DataGridView1.Columns(13).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(14).HeaderText = "NAMA IBU"
        Menu_Data_Kelahiran.DataGridView1.Columns(14).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(15).HeaderText = "TGL LAHIR"
        Menu_Data_Kelahiran.DataGridView1.Columns(15).Width = 200
        Menu_Data_Kelahiran.DataGridView1.Columns(16).HeaderText = "UMUR"
        Menu_Data_Kelahiran.DataGridView1.Columns(16).Width = 100

        Menu_Data_Kelahiran.DataGridView1.Columns(17).HeaderText = "PEKERJAAN"
        Menu_Data_Kelahiran.DataGridView1.Columns(17).Width = 100
        Menu_Data_Kelahiran.DataGridView1.Columns(18).HeaderText = "ALAMAT"
        Menu_Data_Kelahiran.DataGridView1.Columns(18).Width = 200

    End Sub
End Class