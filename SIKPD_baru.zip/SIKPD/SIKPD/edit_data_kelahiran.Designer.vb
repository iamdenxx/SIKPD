﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class edit_data_kelahiran
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.etxt_alamat_ibu = New System.Windows.Forms.TextBox()
        Me.etxt_alamat_ayah = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.etxt_tgl_lahir_ayah = New System.Windows.Forms.DateTimePicker()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.etxt_pekerjaan_ayah = New System.Windows.Forms.TextBox()
        Me.etxt_umur_ayah = New System.Windows.Forms.TextBox()
        Me.etxt_nik_ayah = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.etxt_nama_ayah = New System.Windows.Forms.TextBox()
        Me.etxt_tgl_lahir_ibu = New System.Windows.Forms.DateTimePicker()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.etxt_pekerjaan_ibu = New System.Windows.Forms.TextBox()
        Me.etxt_umur_ibu = New System.Windows.Forms.TextBox()
        Me.etxt_nik_ibu = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.etxt_nama_ibu = New System.Windows.Forms.TextBox()
        Me.erbtn_P = New System.Windows.Forms.RadioButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.etxt_tempat_lahir = New System.Windows.Forms.TextBox()
        Me.etxt_nama = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.erbtn_L = New System.Windows.Forms.RadioButton()
        Me.etxt_tgl_lahir = New System.Windows.Forms.DateTimePicker()
        Me.etxt_nik = New System.Windows.Forms.TextBox()
        Me.ebtn_batal = New System.Windows.Forms.Button()
        Me.ebtn_simpan = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.etxt_id = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.ecmb_agama = New System.Windows.Forms.ComboBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(81, 222)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(40, 16)
        Me.Label33.TabIndex = 48
        Me.Label33.Text = "Alamat"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(58, 222)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(40, 16)
        Me.Label32.TabIndex = 47
        Me.Label32.Text = "Alamat"
        '
        'etxt_alamat_ibu
        '
        Me.etxt_alamat_ibu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_alamat_ibu.Location = New System.Drawing.Point(138, 219)
        Me.etxt_alamat_ibu.Name = "etxt_alamat_ibu"
        Me.etxt_alamat_ibu.Size = New System.Drawing.Size(200, 21)
        Me.etxt_alamat_ibu.TabIndex = 46
        '
        'etxt_alamat_ayah
        '
        Me.etxt_alamat_ayah.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_alamat_ayah.Location = New System.Drawing.Point(115, 219)
        Me.etxt_alamat_ayah.Name = "etxt_alamat_ayah"
        Me.etxt_alamat_ayah.Size = New System.Drawing.Size(200, 21)
        Me.etxt_alamat_ayah.TabIndex = 45
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(69, 192)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(53, 16)
        Me.Label13.TabIndex = 44
        Me.Label13.Text = "Pekerjaan"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Adobe Fan Heiti Std B", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(311, 16)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(220, 30)
        Me.Label31.TabIndex = 50
        Me.Label31.Text = "Edit Data Kelahiran"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(187, 19)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(46, 16)
        Me.Label37.TabIndex = 47
        Me.Label37.Text = "Data Ibu"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.etxt_tgl_lahir_ayah)
        Me.Panel2.Controls.Add(Me.Label32)
        Me.Panel2.Controls.Add(Me.etxt_alamat_ayah)
        Me.Panel2.Controls.Add(Me.Label36)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.etxt_pekerjaan_ayah)
        Me.Panel2.Controls.Add(Me.etxt_umur_ayah)
        Me.Panel2.Controls.Add(Me.etxt_nik_ayah)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.etxt_nama_ayah)
        Me.Panel2.Location = New System.Drawing.Point(-1, 200)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(427, 439)
        Me.Panel2.TabIndex = 21
        '
        'etxt_tgl_lahir_ayah
        '
        Me.etxt_tgl_lahir_ayah.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir_ayah.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir_ayah.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl_lahir_ayah.Location = New System.Drawing.Point(115, 133)
        Me.etxt_tgl_lahir_ayah.Name = "etxt_tgl_lahir_ayah"
        Me.etxt_tgl_lahir_ayah.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl_lahir_ayah.TabIndex = 62
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(173, 19)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(54, 16)
        Me.Label36.TabIndex = 46
        Me.Label36.Text = "Data Ayah"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(46, 192)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 16)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "Pekerjaan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(64, 164)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 16)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "Umur"
        '
        'etxt_pekerjaan_ayah
        '
        Me.etxt_pekerjaan_ayah.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_pekerjaan_ayah.Location = New System.Drawing.Point(115, 192)
        Me.etxt_pekerjaan_ayah.Name = "etxt_pekerjaan_ayah"
        Me.etxt_pekerjaan_ayah.Size = New System.Drawing.Size(200, 21)
        Me.etxt_pekerjaan_ayah.TabIndex = 29
        '
        'etxt_umur_ayah
        '
        Me.etxt_umur_ayah.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_umur_ayah.Location = New System.Drawing.Point(115, 161)
        Me.etxt_umur_ayah.Name = "etxt_umur_ayah"
        Me.etxt_umur_ayah.Size = New System.Drawing.Size(48, 21)
        Me.etxt_umur_ayah.TabIndex = 28
        '
        'etxt_nik_ayah
        '
        Me.etxt_nik_ayah.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nik_ayah.Location = New System.Drawing.Point(115, 80)
        Me.etxt_nik_ayah.Name = "etxt_nik_ayah"
        Me.etxt_nik_ayah.Size = New System.Drawing.Size(200, 21)
        Me.etxt_nik_ayah.TabIndex = 22
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(30, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 16)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Tanggal Lahir"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(39, 110)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 16)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "Nama Ayah"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(74, 80)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(25, 16)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "NIK"
        '
        'etxt_nama_ayah
        '
        Me.etxt_nama_ayah.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nama_ayah.Location = New System.Drawing.Point(115, 107)
        Me.etxt_nama_ayah.Name = "etxt_nama_ayah"
        Me.etxt_nama_ayah.Size = New System.Drawing.Size(200, 21)
        Me.etxt_nama_ayah.TabIndex = 24
        '
        'etxt_tgl_lahir_ibu
        '
        Me.etxt_tgl_lahir_ibu.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir_ibu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir_ibu.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl_lahir_ibu.Location = New System.Drawing.Point(138, 137)
        Me.etxt_tgl_lahir_ibu.Name = "etxt_tgl_lahir_ibu"
        Me.etxt_tgl_lahir_ibu.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl_lahir_ibu.TabIndex = 63
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(50, 140)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(72, 16)
        Me.Label39.TabIndex = 61
        Me.Label39.Text = "Tanggal Lahir"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(87, 167)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(34, 16)
        Me.Label15.TabIndex = 42
        Me.Label15.Text = "Umur"
        '
        'etxt_pekerjaan_ibu
        '
        Me.etxt_pekerjaan_ibu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_pekerjaan_ibu.Location = New System.Drawing.Point(138, 192)
        Me.etxt_pekerjaan_ibu.Name = "etxt_pekerjaan_ibu"
        Me.etxt_pekerjaan_ibu.Size = New System.Drawing.Size(200, 21)
        Me.etxt_pekerjaan_ibu.TabIndex = 41
        '
        'etxt_umur_ibu
        '
        Me.etxt_umur_ibu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_umur_ibu.Location = New System.Drawing.Point(138, 164)
        Me.etxt_umur_ibu.Name = "etxt_umur_ibu"
        Me.etxt_umur_ibu.Size = New System.Drawing.Size(48, 21)
        Me.etxt_umur_ibu.TabIndex = 40
        '
        'etxt_nik_ibu
        '
        Me.etxt_nik_ibu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nik_ibu.Location = New System.Drawing.Point(138, 83)
        Me.etxt_nik_ibu.Name = "etxt_nik_ibu"
        Me.etxt_nik_ibu.Size = New System.Drawing.Size(200, 21)
        Me.etxt_nik_ibu.TabIndex = 34
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(70, 113)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(52, 16)
        Me.Label17.TabIndex = 38
        Me.Label17.Text = "Nama Ibu"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(97, 83)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(25, 16)
        Me.Label18.TabIndex = 35
        Me.Label18.Text = "NIK"
        '
        'etxt_nama_ibu
        '
        Me.etxt_nama_ibu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nama_ibu.Location = New System.Drawing.Point(138, 110)
        Me.etxt_nama_ibu.Name = "etxt_nama_ibu"
        Me.etxt_nama_ibu.Size = New System.Drawing.Size(200, 21)
        Me.etxt_nama_ibu.TabIndex = 36
        '
        'erbtn_P
        '
        Me.erbtn_P.AutoSize = True
        Me.erbtn_P.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_P.Location = New System.Drawing.Point(447, 140)
        Me.erbtn_P.Name = "erbtn_P"
        Me.erbtn_P.Size = New System.Drawing.Size(96, 20)
        Me.erbtn_P.TabIndex = 6
        Me.erbtn_P.TabStop = True
        Me.erbtn_P.Text = "Perempuan"
        Me.erbtn_P.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(272, 115)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 16)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "TGL Lahir"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(287, 169)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 16)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Agama"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(293, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(34, 16)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Nama"
        '
        'etxt_tempat_lahir
        '
        Me.etxt_tempat_lahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tempat_lahir.Location = New System.Drawing.Point(343, 85)
        Me.etxt_tempat_lahir.Name = "etxt_tempat_lahir"
        Me.etxt_tempat_lahir.Size = New System.Drawing.Size(200, 21)
        Me.etxt_tempat_lahir.TabIndex = 14
        '
        'etxt_nama
        '
        Me.etxt_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nama.Location = New System.Drawing.Point(343, 58)
        Me.etxt_nama.Name = "etxt_nama"
        Me.etxt_nama.Size = New System.Drawing.Size(200, 21)
        Me.etxt_nama.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(302, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 16)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "NIK"
        '
        'erbtn_L
        '
        Me.erbtn_L.AutoSize = True
        Me.erbtn_L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_L.Location = New System.Drawing.Point(343, 140)
        Me.erbtn_L.Name = "erbtn_L"
        Me.erbtn_L.Size = New System.Drawing.Size(80, 20)
        Me.erbtn_L.TabIndex = 3
        Me.erbtn_L.TabStop = True
        Me.erbtn_L.Text = "Laki-Laki"
        Me.erbtn_L.UseVisualStyleBackColor = True
        '
        'etxt_tgl_lahir
        '
        Me.etxt_tgl_lahir.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl_lahir.Location = New System.Drawing.Point(343, 112)
        Me.etxt_tgl_lahir.Name = "etxt_tgl_lahir"
        Me.etxt_tgl_lahir.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl_lahir.TabIndex = 2
        '
        'etxt_nik
        '
        Me.etxt_nik.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nik.Location = New System.Drawing.Point(343, 31)
        Me.etxt_nik.Name = "etxt_nik"
        Me.etxt_nik.Size = New System.Drawing.Size(200, 21)
        Me.etxt_nik.TabIndex = 0
        '
        'ebtn_batal
        '
        Me.ebtn_batal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ebtn_batal.Location = New System.Drawing.Point(736, 670)
        Me.ebtn_batal.Name = "ebtn_batal"
        Me.ebtn_batal.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_batal.TabIndex = 49
        Me.ebtn_batal.Text = "Batal"
        Me.ebtn_batal.UseVisualStyleBackColor = True
        '
        'ebtn_simpan
        '
        Me.ebtn_simpan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ebtn_simpan.Location = New System.Drawing.Point(655, 670)
        Me.ebtn_simpan.Name = "ebtn_simpan"
        Me.ebtn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_simpan.TabIndex = 48
        Me.ebtn_simpan.Text = "Simpan"
        Me.ebtn_simpan.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(258, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 16)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Tempat Lahir"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(254, 140)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 16)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Jenis Kelamin"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.etxt_id)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.ecmb_agama)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.erbtn_P)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.etxt_tempat_lahir)
        Me.Panel1.Controls.Add(Me.etxt_nama)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.erbtn_L)
        Me.Panel1.Controls.Add(Me.etxt_tgl_lahir)
        Me.Panel1.Controls.Add(Me.etxt_nik)
        Me.Panel1.Location = New System.Drawing.Point(12, 49)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(799, 617)
        Me.Panel1.TabIndex = 47
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial Narrow", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(385, 5)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 16)
        Me.Label11.TabIndex = 64
        Me.Label11.Text = "Data Anak"
        '
        'etxt_id
        '
        Me.etxt_id.AutoSize = True
        Me.etxt_id.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_id.Location = New System.Drawing.Point(27, 0)
        Me.etxt_id.Name = "etxt_id"
        Me.etxt_id.Size = New System.Drawing.Size(22, 16)
        Me.etxt_id.TabIndex = 59
        Me.etxt_id.Text = "no"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(-1, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(30, 16)
        Me.Label38.TabIndex = 58
        Me.Label38.Text = "No :"
        '
        'ecmb_agama
        '
        Me.ecmb_agama.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ecmb_agama.FormattingEnabled = True
        Me.ecmb_agama.Items.AddRange(New Object() {"ISLAM", "HINDU", "KRISTEN", "BUDHA", "KONGHUCU"})
        Me.ecmb_agama.Location = New System.Drawing.Point(343, 166)
        Me.ecmb_agama.Name = "ecmb_agama"
        Me.ecmb_agama.Size = New System.Drawing.Size(121, 23)
        Me.ecmb_agama.TabIndex = 45
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.etxt_tgl_lahir_ibu)
        Me.Panel3.Controls.Add(Me.Label37)
        Me.Panel3.Controls.Add(Me.etxt_nik_ibu)
        Me.Panel3.Controls.Add(Me.etxt_nama_ibu)
        Me.Panel3.Controls.Add(Me.Label39)
        Me.Panel3.Controls.Add(Me.Label18)
        Me.Panel3.Controls.Add(Me.Label33)
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.etxt_umur_ibu)
        Me.Panel3.Controls.Add(Me.etxt_alamat_ibu)
        Me.Panel3.Controls.Add(Me.etxt_pekerjaan_ibu)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.Label13)
        Me.Panel3.Location = New System.Drawing.Point(416, 200)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(382, 439)
        Me.Panel3.TabIndex = 22
        '
        'edit_data_kelahiran
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(823, 698)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.ebtn_batal)
        Me.Controls.Add(Me.ebtn_simpan)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "edit_data_kelahiran"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SIKPD Demulih"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents etxt_alamat_ibu As System.Windows.Forms.TextBox
    Friend WithEvents etxt_alamat_ayah As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents etxt_pekerjaan_ibu As System.Windows.Forms.TextBox
    Friend WithEvents etxt_umur_ibu As System.Windows.Forms.TextBox
    Friend WithEvents etxt_nik_ibu As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents etxt_nama_ibu As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents etxt_pekerjaan_ayah As System.Windows.Forms.TextBox
    Friend WithEvents etxt_umur_ayah As System.Windows.Forms.TextBox
    Friend WithEvents etxt_nik_ayah As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents etxt_nama_ayah As System.Windows.Forms.TextBox
    Friend WithEvents erbtn_P As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents etxt_tempat_lahir As System.Windows.Forms.TextBox
    Friend WithEvents etxt_nama As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents erbtn_L As System.Windows.Forms.RadioButton
    Friend WithEvents etxt_tgl_lahir As System.Windows.Forms.DateTimePicker
    Friend WithEvents etxt_nik As System.Windows.Forms.TextBox
    Friend WithEvents ebtn_batal As System.Windows.Forms.Button
    Friend WithEvents ebtn_simpan As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ecmb_agama As System.Windows.Forms.ComboBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents etxt_id As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents etxt_tgl_lahir_ibu As System.Windows.Forms.DateTimePicker
    Friend WithEvents etxt_tgl_lahir_ayah As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
