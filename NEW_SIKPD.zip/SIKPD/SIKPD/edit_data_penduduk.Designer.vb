﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class edit_data_penduduk
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ecmb_status = New System.Windows.Forms.ComboBox()
        Me.ebtn_simpan = New System.Windows.Forms.Button()
        Me.ecmb_kewarganegaraan = New System.Windows.Forms.ComboBox()
        Me.etxt_pekerjaan = New System.Windows.Forms.TextBox()
        Me.etxt_alamat = New System.Windows.Forms.RichTextBox()
        Me.erbtn_P = New System.Windows.Forms.RadioButton()
        Me.etxt_tempat_lahir = New System.Windows.Forms.TextBox()
        Me.etxt_nama = New System.Windows.Forms.TextBox()
        Me.erbtn_L = New System.Windows.Forms.RadioButton()
        Me.etxt_tgl_lahir = New System.Windows.Forms.DateTimePicker()
        Me.ecmb_agama = New System.Windows.Forms.ComboBox()
        Me.etxt_nik = New System.Windows.Forms.TextBox()
        Me.ebtn_batal = New System.Windows.Forms.Button()
        Me.etxt_pendidikan = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Adobe Fan Heiti Std B", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(130, 20)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(230, 30)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "Edit Data Penduduk"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(50, 436)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(105, 16)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Status Perkawinan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(53, 393)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(102, 16)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "Kewarganegaraan"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(88, 352)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 16)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Pendidikan"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(96, 312)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 16)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Pekerjaan"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(111, 273)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 16)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Agama"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(111, 199)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 16)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Alamat"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(74, 168)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 16)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Jenis Kelamin"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(95, 145)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 16)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "TGL Lahir"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(78, 109)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 16)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Tempat Lahir"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(118, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 16)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(128, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 16)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "NIK"
        '
        'ecmb_status
        '
        Me.ecmb_status.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ecmb_status.FormattingEnabled = True
        Me.ecmb_status.Items.AddRange(New Object() {"MENIKAH", "BELUM MENIKAH"})
        Me.ecmb_status.Location = New System.Drawing.Point(169, 430)
        Me.ecmb_status.Name = "ecmb_status"
        Me.ecmb_status.Size = New System.Drawing.Size(121, 28)
        Me.ecmb_status.TabIndex = 11
        '
        'ebtn_simpan
        '
        Me.ebtn_simpan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ebtn_simpan.Location = New System.Drawing.Point(306, 556)
        Me.ebtn_simpan.Name = "ebtn_simpan"
        Me.ebtn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_simpan.TabIndex = 25
        Me.ebtn_simpan.Text = "Simpan"
        Me.ebtn_simpan.UseVisualStyleBackColor = True
        '
        'ecmb_kewarganegaraan
        '
        Me.ecmb_kewarganegaraan.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ecmb_kewarganegaraan.FormattingEnabled = True
        Me.ecmb_kewarganegaraan.Items.AddRange(New Object() {"WNI", "WNA"})
        Me.ecmb_kewarganegaraan.Location = New System.Drawing.Point(169, 387)
        Me.ecmb_kewarganegaraan.Name = "ecmb_kewarganegaraan"
        Me.ecmb_kewarganegaraan.Size = New System.Drawing.Size(121, 28)
        Me.ecmb_kewarganegaraan.TabIndex = 10
        '
        'etxt_pekerjaan
        '
        Me.etxt_pekerjaan.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_pekerjaan.Location = New System.Drawing.Point(169, 306)
        Me.etxt_pekerjaan.Name = "etxt_pekerjaan"
        Me.etxt_pekerjaan.Size = New System.Drawing.Size(200, 26)
        Me.etxt_pekerjaan.TabIndex = 8
        '
        'etxt_alamat
        '
        Me.etxt_alamat.Location = New System.Drawing.Point(169, 199)
        Me.etxt_alamat.Name = "etxt_alamat"
        Me.etxt_alamat.Size = New System.Drawing.Size(200, 58)
        Me.etxt_alamat.TabIndex = 7
        Me.etxt_alamat.Text = ""
        '
        'erbtn_P
        '
        Me.erbtn_P.AutoSize = True
        Me.erbtn_P.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_P.Location = New System.Drawing.Point(282, 168)
        Me.erbtn_P.Name = "erbtn_P"
        Me.erbtn_P.Size = New System.Drawing.Size(96, 20)
        Me.erbtn_P.TabIndex = 6
        Me.erbtn_P.TabStop = True
        Me.erbtn_P.Text = "Perempuan"
        Me.erbtn_P.UseVisualStyleBackColor = True
        '
        'etxt_tempat_lahir
        '
        Me.etxt_tempat_lahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tempat_lahir.Location = New System.Drawing.Point(169, 103)
        Me.etxt_tempat_lahir.Name = "etxt_tempat_lahir"
        Me.etxt_tempat_lahir.Size = New System.Drawing.Size(200, 26)
        Me.etxt_tempat_lahir.TabIndex = 5
        '
        'etxt_nama
        '
        Me.etxt_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nama.Location = New System.Drawing.Point(169, 61)
        Me.etxt_nama.Name = "etxt_nama"
        Me.etxt_nama.Size = New System.Drawing.Size(200, 26)
        Me.etxt_nama.TabIndex = 4
        '
        'erbtn_L
        '
        Me.erbtn_L.AutoSize = True
        Me.erbtn_L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_L.Location = New System.Drawing.Point(169, 168)
        Me.erbtn_L.Name = "erbtn_L"
        Me.erbtn_L.Size = New System.Drawing.Size(80, 20)
        Me.erbtn_L.TabIndex = 3
        Me.erbtn_L.TabStop = True
        Me.erbtn_L.Text = "Laki-Laki"
        Me.erbtn_L.UseVisualStyleBackColor = True
        '
        'etxt_tgl_lahir
        '
        Me.etxt_tgl_lahir.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_lahir.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl_lahir.Location = New System.Drawing.Point(169, 140)
        Me.etxt_tgl_lahir.Name = "etxt_tgl_lahir"
        Me.etxt_tgl_lahir.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl_lahir.TabIndex = 2
        '
        'ecmb_agama
        '
        Me.ecmb_agama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ecmb_agama.FormattingEnabled = True
        Me.ecmb_agama.Items.AddRange(New Object() {"ISLAM", "HINDU", "KRISTEN", "BUDHA", "KONGHUCU"})
        Me.ecmb_agama.Location = New System.Drawing.Point(169, 267)
        Me.ecmb_agama.Name = "ecmb_agama"
        Me.ecmb_agama.Size = New System.Drawing.Size(121, 28)
        Me.ecmb_agama.TabIndex = 1
        '
        'etxt_nik
        '
        Me.etxt_nik.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nik.Location = New System.Drawing.Point(169, 20)
        Me.etxt_nik.Name = "etxt_nik"
        Me.etxt_nik.Size = New System.Drawing.Size(200, 26)
        Me.etxt_nik.TabIndex = 0
        '
        'ebtn_batal
        '
        Me.ebtn_batal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ebtn_batal.Location = New System.Drawing.Point(387, 556)
        Me.ebtn_batal.Name = "ebtn_batal"
        Me.ebtn_batal.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_batal.TabIndex = 26
        Me.ebtn_batal.Text = "Batal"
        Me.ebtn_batal.UseVisualStyleBackColor = True
        '
        'etxt_pendidikan
        '
        Me.etxt_pendidikan.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_pendidikan.Location = New System.Drawing.Point(169, 346)
        Me.etxt_pendidikan.Name = "etxt_pendidikan"
        Me.etxt_pendidikan.Size = New System.Drawing.Size(200, 26)
        Me.etxt_pendidikan.TabIndex = 9
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.ecmb_status)
        Me.Panel1.Controls.Add(Me.ecmb_kewarganegaraan)
        Me.Panel1.Controls.Add(Me.etxt_pendidikan)
        Me.Panel1.Controls.Add(Me.etxt_pekerjaan)
        Me.Panel1.Controls.Add(Me.etxt_alamat)
        Me.Panel1.Controls.Add(Me.erbtn_P)
        Me.Panel1.Controls.Add(Me.etxt_tempat_lahir)
        Me.Panel1.Controls.Add(Me.etxt_nama)
        Me.Panel1.Controls.Add(Me.erbtn_L)
        Me.Panel1.Controls.Add(Me.etxt_tgl_lahir)
        Me.Panel1.Controls.Add(Me.ecmb_agama)
        Me.Panel1.Controls.Add(Me.etxt_nik)
        Me.Panel1.Location = New System.Drawing.Point(13, 69)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(449, 473)
        Me.Panel1.TabIndex = 24
        '
        'edit_data_penduduk
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(475, 595)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.ebtn_simpan)
        Me.Controls.Add(Me.ebtn_batal)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "edit_data_penduduk"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SIKPD Demulih"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ecmb_status As System.Windows.Forms.ComboBox
    Friend WithEvents ebtn_simpan As System.Windows.Forms.Button
    Friend WithEvents ecmb_kewarganegaraan As System.Windows.Forms.ComboBox
    Friend WithEvents etxt_pekerjaan As System.Windows.Forms.TextBox
    Friend WithEvents etxt_alamat As System.Windows.Forms.RichTextBox
    Friend WithEvents erbtn_P As System.Windows.Forms.RadioButton
    Friend WithEvents etxt_tempat_lahir As System.Windows.Forms.TextBox
    Friend WithEvents etxt_nama As System.Windows.Forms.TextBox
    Friend WithEvents erbtn_L As System.Windows.Forms.RadioButton
    Friend WithEvents etxt_tgl_lahir As System.Windows.Forms.DateTimePicker
    Friend WithEvents ecmb_agama As System.Windows.Forms.ComboBox
    Friend WithEvents etxt_nik As System.Windows.Forms.TextBox
    Friend WithEvents ebtn_batal As System.Windows.Forms.Button
    Friend WithEvents etxt_pendidikan As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
