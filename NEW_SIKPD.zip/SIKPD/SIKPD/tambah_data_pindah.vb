﻿Imports System.Data
Imports System.Data.OleDb
Imports MySql.Data.MySqlClient
Public Class tambah_data_pindah
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_pindah As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim nomerbaru As String
    Dim nomerterakhir As String
    Dim nourutbaru As Integer
    Dim no As DataTable
    Sub Clear()
        txt_nama.Text = ""
        txt_tempat_lahir.Text = ""
        txt_tgl.Value = Date.Now
        txt_tgl_pindah.Value = Date.Now
        txt_alamat_asal.Text = ""
        cmb_agama.Text = ""
        cmb_kw.Text = ""
        txt_tempat_lahir.Text = ""
        txt_alamat_asal.Text = ""
        txt_alamat_sekarang.Text = ""
    End Sub
    Sub Kodeotomatis()
        no = Proses.ExecuteQuery("Select * From tb_pindah order by id_pindah desc")

        If no.Rows.Count = 0 Then
            nomerbaru = "0001"
        Else
            nomerterakhir = no.Rows(0).Item(0)
            nomerterakhir = Microsoft.VisualBasic.Right(nomerterakhir, 4)
            nourutbaru = CInt(nomerterakhir) + 1
            nomerbaru = "000" + CStr(nourutbaru)
            nomerbaru = Microsoft.VisualBasic.Right(nomerbaru, 4)
        End If
        txt_id.Text = nomerbaru

    End Sub
    Private Sub kode_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Kodeotomatis()
    End Sub
   Sub Data_Record()
        tb_pindah = Proses.ExecuteQuery("Select id_pindah,nik,nama,tempat_lahir,tanggal_lahir,jenis_kelamin,agama,kewarganegaraan, alamat_asal,alamat_sekarang,tanggal_pindah From tb_pindah  order by id_pindah DESC")
        Menu_Data_Pindah.DataGridView1.DataSource = tb_pindah
        Menu_Data_Pindah.DataGridView1.Columns(0).HeaderText = "ID"
        Menu_Data_Pindah.DataGridView1.Columns(0).Width = 100
        Menu_Data_Pindah.DataGridView1.Columns(1).HeaderText = "NIK"
        Menu_Data_Pindah.DataGridView1.Columns(1).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(2).HeaderText = "NAMA"
        Menu_Data_Pindah.DataGridView1.Columns(2).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(3).HeaderText = "TEMPAT LAHIR"
        Menu_Data_Pindah.DataGridView1.Columns(3).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(4).HeaderText = "TGL LAHIR"
        Menu_Data_Pindah.DataGridView1.Columns(4).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(5).HeaderText = "JENIS KELAMIN"
        Menu_Data_Pindah.DataGridView1.Columns(5).Width = 150
        Menu_Data_Pindah.DataGridView1.Columns(6).HeaderText = "AGAMA"
        Menu_Data_Pindah.DataGridView1.Columns(6).Width = 100
        Menu_Data_Pindah.DataGridView1.Columns(7).HeaderText = "KEWARGANEGARAAN"
        Menu_Data_Pindah.DataGridView1.Columns(7).Width = 100
        Menu_Data_Pindah.DataGridView1.Columns(8).HeaderText = "ALAMAT ASAL"
        Menu_Data_Pindah.DataGridView1.Columns(8).Width = 200
        Menu_Data_Pindah.DataGridView1.Columns(9).HeaderText = "ALAMAT SEKARANG"
        Menu_Data_Pindah.DataGridView1.Columns(9).Width = 200
        Menu_Data_Pindah.DataGridView1.Columns(10).HeaderText = "TANGGAL PINDAH"
        Menu_Data_Pindah.DataGridView1.Columns(10).Width = 100
    End Sub
    Private Sub txt_nik_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_nik.KeyPress
        If (e.KeyChar = Chr(13)) Then
            conn = New MySqlConnection("server=localhost; user id=root; password =; database=sikpd;")
            conn.Open()
            Try
                cd = New MySqlCommand("select * from tb_penduduk where nik ='" & txt_nik.Text & "'", conn)
                rd = cd.ExecuteReader()
                rd.Read()
                If rd.HasRows Then
                    txt_nama.Text = rd.Item("nama")
                    txt_tgl.Value = rd.Item("tanggal_lahir")
                    cmb_agama.Text = rd.Item("agama")
                    txt_tempat_lahir.Text = rd.Item("tempat_lahir")
                    txt_alamat_asal.Text = rd.Item("alamat")
                    txt_alamat_sekarang.Focus()
                    If rd.Item("jenis_kelamin") = "Laki-Laki" Then
                        rbtn_L.Checked = True
                    Else
                        rbtn_P.Checked = True
                        cmb_kw.Text = rd.Item("kewarganegaraan")
                    End If
                End If

            Catch ex As Exception

                MessageBox.Show("Koneksi Gagal !!!, karena " & ex.Message)
            End Try
            conn.Close()
        End If
    End Sub

    Private Sub btn_simpan_Click(sender As Object, e As EventArgs) Handles btn_simpan.Click
        Dim jk As New TextBox
        If (rbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If

        If txt_nik.Text = "" Then txt_nik.Focus() : Exit Sub
        If txt_nama.Text = "" Then txt_nama.Focus() : Exit Sub
        If txt_alamat_asal.Text = "" Then txt_alamat_asal.Focus() : Exit Sub
        If txt_alamat_sekarang.Text = "" Then txt_alamat_sekarang.Focus() : Exit Sub
        If cmb_agama.Text = "" Then cmb_agama.Focus() : Exit Sub
        If cmb_kw.Text = "" Then cmb_kw.Focus() : Exit Sub

        SQL = "Insert Into tb_pindah (id_pindah, nik,nama,tempat_lahir, tanggal_lahir,jenis_kelamin, agama,kewarganegaraan, alamat_asal,alamat_sekarang, tanggal_pindah) Values ('" & txt_id.Text & "','" & txt_nik.Text & "','" & txt_nama.Text & "','" & txt_tempat_lahir.Text & "','" & Format(txt_tgl.Value, "yyyy-MM-dd") & "','" & jk.Text & "','" & cmb_agama.Text & "','" & cmb_kw.Text & "','" & txt_alamat_asal.Text & "','" & txt_alamat_asal.Text & "','" & Format(txt_tgl_pindah.Value, "yyyy-MM-dd") & "')"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Ditambahkan", "Success Message", MessageBoxButtons.OK)
        Dim msg As DialogResult
        msg = MessageBox.Show("Ada Data yang akan diinputkan lagi ?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If msg = Windows.Forms.DialogResult.No Then
            Call Data_Chart()
            Call Data_Record()
            Call Clear()
            Me.Close()
        Else
            Call Clear()
        End If
        Call Kodeotomatis()
    End Sub
    Sub Data_Chart()
        conn = New MySqlConnection
        conn.ConnectionString =
       "server=localhost;userid=root;password=;database=sikpd"
        Dim READER As MySqlDataReader

        Try
            conn.Open()
            Dim Query As String
            Query = "SELECT  DATE_FORMAT(tanggal_pindah,'%M') as bln, COUNT(*)AS jmlh FROM tb_pindah where YEAR(tanggal_pindah)='" & Menu_Data_Pindah.Label3.Text & "' GROUP BY MONTH(tanggal_pindah)"
            cd = New MySqlCommand(Query, conn)
            READER = cd.ExecuteReader
            While READER.Read

                Menu_Data_Pindah.Chart1.Series("Data Pindah").Points.AddXY(READER("bln"), READER("jmlh"))


            End While
            conn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try
    End Sub
    Private Sub btn_batal_Click(sender As Object, e As EventArgs) Handles btn_batal.Click
        Call Clear()
        Me.Close()
    End Sub
End Class