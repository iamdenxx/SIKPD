﻿Public Class lap_kelahiran

End Class