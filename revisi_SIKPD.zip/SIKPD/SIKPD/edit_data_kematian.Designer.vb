﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class edit_data_kematian
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ebtn_simpan = New System.Windows.Forms.Button()
        Me.etxt_tempat_meninggal = New System.Windows.Forms.TextBox()
        Me.erbtn_P = New System.Windows.Forms.RadioButton()
        Me.etxt_tempat_lahir = New System.Windows.Forms.TextBox()
        Me.etxt_nama = New System.Windows.Forms.TextBox()
        Me.erbtn_L = New System.Windows.Forms.RadioButton()
        Me.etxt_tgl = New System.Windows.Forms.DateTimePicker()
        Me.ecmb_agama = New System.Windows.Forms.ComboBox()
        Me.etxt_nik = New System.Windows.Forms.TextBox()
        Me.ebtn_batal = New System.Windows.Forms.Button()
        Me.etxt_alamat = New System.Windows.Forms.RichTextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.etxt_tgl_meninggal = New System.Windows.Forms.DateTimePicker()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Adobe Fan Heiti Std B", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(143, 18)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(222, 30)
        Me.Label31.TabIndex = 51
        Me.Label31.Text = "Edit Data Kematian"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(71, 365)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(88, 16)
        Me.Label9.TabIndex = 39
        Me.Label9.Text = "TGL Meninggal"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(54, 325)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(105, 16)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Tempat Meninggal"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(115, 286)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 16)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "Agama"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(115, 212)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 16)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Alamat"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(78, 181)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 16)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Jenis Kelamin"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(99, 158)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 16)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "TGL Lahir"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(82, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 16)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Tempat Lahir"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(122, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 16)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(132, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 16)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "NIK"
        '
        'ebtn_simpan
        '
        Me.ebtn_simpan.Location = New System.Drawing.Point(333, 485)
        Me.ebtn_simpan.Name = "ebtn_simpan"
        Me.ebtn_simpan.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_simpan.TabIndex = 49
        Me.ebtn_simpan.Text = "Simpan"
        Me.ebtn_simpan.UseVisualStyleBackColor = True
        '
        'etxt_tempat_meninggal
        '
        Me.etxt_tempat_meninggal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tempat_meninggal.Location = New System.Drawing.Point(173, 319)
        Me.etxt_tempat_meninggal.Name = "etxt_tempat_meninggal"
        Me.etxt_tempat_meninggal.Size = New System.Drawing.Size(200, 26)
        Me.etxt_tempat_meninggal.TabIndex = 29
        '
        'erbtn_P
        '
        Me.erbtn_P.AutoSize = True
        Me.erbtn_P.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_P.Location = New System.Drawing.Point(286, 181)
        Me.erbtn_P.Name = "erbtn_P"
        Me.erbtn_P.Size = New System.Drawing.Size(96, 20)
        Me.erbtn_P.TabIndex = 27
        Me.erbtn_P.TabStop = True
        Me.erbtn_P.Text = "Perempuan"
        Me.erbtn_P.UseVisualStyleBackColor = True
        '
        'etxt_tempat_lahir
        '
        Me.etxt_tempat_lahir.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tempat_lahir.Location = New System.Drawing.Point(173, 116)
        Me.etxt_tempat_lahir.Name = "etxt_tempat_lahir"
        Me.etxt_tempat_lahir.Size = New System.Drawing.Size(200, 26)
        Me.etxt_tempat_lahir.TabIndex = 26
        '
        'etxt_nama
        '
        Me.etxt_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nama.Location = New System.Drawing.Point(173, 74)
        Me.etxt_nama.Name = "etxt_nama"
        Me.etxt_nama.Size = New System.Drawing.Size(200, 26)
        Me.etxt_nama.TabIndex = 25
        '
        'erbtn_L
        '
        Me.erbtn_L.AutoSize = True
        Me.erbtn_L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.erbtn_L.Location = New System.Drawing.Point(173, 181)
        Me.erbtn_L.Name = "erbtn_L"
        Me.erbtn_L.Size = New System.Drawing.Size(80, 20)
        Me.erbtn_L.TabIndex = 24
        Me.erbtn_L.TabStop = True
        Me.erbtn_L.Text = "Laki-Laki"
        Me.erbtn_L.UseVisualStyleBackColor = True
        '
        'etxt_tgl
        '
        Me.etxt_tgl.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl.Location = New System.Drawing.Point(173, 153)
        Me.etxt_tgl.Name = "etxt_tgl"
        Me.etxt_tgl.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl.TabIndex = 23
        '
        'ecmb_agama
        '
        Me.ecmb_agama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ecmb_agama.FormattingEnabled = True
        Me.ecmb_agama.Items.AddRange(New Object() {"ISLAM", "HINDU", "KRISTEN", "BUDHA", "KONGHUCU"})
        Me.ecmb_agama.Location = New System.Drawing.Point(173, 280)
        Me.ecmb_agama.Name = "ecmb_agama"
        Me.ecmb_agama.Size = New System.Drawing.Size(121, 28)
        Me.ecmb_agama.TabIndex = 22
        '
        'etxt_nik
        '
        Me.etxt_nik.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_nik.Location = New System.Drawing.Point(173, 33)
        Me.etxt_nik.Name = "etxt_nik"
        Me.etxt_nik.Size = New System.Drawing.Size(200, 26)
        Me.etxt_nik.TabIndex = 21
        '
        'ebtn_batal
        '
        Me.ebtn_batal.Location = New System.Drawing.Point(414, 485)
        Me.ebtn_batal.Name = "ebtn_batal"
        Me.ebtn_batal.Size = New System.Drawing.Size(75, 23)
        Me.ebtn_batal.TabIndex = 50
        Me.ebtn_batal.Text = "Batal"
        Me.ebtn_batal.UseVisualStyleBackColor = True
        '
        'etxt_alamat
        '
        Me.etxt_alamat.Location = New System.Drawing.Point(173, 212)
        Me.etxt_alamat.Name = "etxt_alamat"
        Me.etxt_alamat.Size = New System.Drawing.Size(200, 58)
        Me.etxt_alamat.TabIndex = 28
        Me.etxt_alamat.Text = ""
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.etxt_tgl_meninggal)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.etxt_tempat_meninggal)
        Me.Panel1.Controls.Add(Me.etxt_alamat)
        Me.Panel1.Controls.Add(Me.erbtn_P)
        Me.Panel1.Controls.Add(Me.etxt_tempat_lahir)
        Me.Panel1.Controls.Add(Me.etxt_nama)
        Me.Panel1.Controls.Add(Me.erbtn_L)
        Me.Panel1.Controls.Add(Me.etxt_tgl)
        Me.Panel1.Controls.Add(Me.ecmb_agama)
        Me.Panel1.Controls.Add(Me.etxt_nik)
        Me.Panel1.Location = New System.Drawing.Point(12, 63)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(477, 416)
        Me.Panel1.TabIndex = 48
        '
        'etxt_tgl_meninggal
        '
        Me.etxt_tgl_meninggal.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_meninggal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etxt_tgl_meninggal.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.etxt_tgl_meninggal.Location = New System.Drawing.Point(173, 360)
        Me.etxt_tgl_meninggal.Name = "etxt_tgl_meninggal"
        Me.etxt_tgl_meninggal.Size = New System.Drawing.Size(112, 22)
        Me.etxt_tgl_meninggal.TabIndex = 40
        '
        'edit_data_kematian
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(501, 523)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.ebtn_simpan)
        Me.Controls.Add(Me.ebtn_batal)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "edit_data_kematian"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SIKPD Demulih"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ebtn_simpan As System.Windows.Forms.Button
    Friend WithEvents etxt_tempat_meninggal As System.Windows.Forms.TextBox
    Friend WithEvents erbtn_P As System.Windows.Forms.RadioButton
    Friend WithEvents etxt_tempat_lahir As System.Windows.Forms.TextBox
    Friend WithEvents etxt_nama As System.Windows.Forms.TextBox
    Friend WithEvents erbtn_L As System.Windows.Forms.RadioButton
    Friend WithEvents etxt_tgl As System.Windows.Forms.DateTimePicker
    Friend WithEvents ecmb_agama As System.Windows.Forms.ComboBox
    Friend WithEvents etxt_nik As System.Windows.Forms.TextBox
    Friend WithEvents ebtn_batal As System.Windows.Forms.Button
    Friend WithEvents etxt_alamat As System.Windows.Forms.RichTextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents etxt_tgl_meninggal As System.Windows.Forms.DateTimePicker
End Class
