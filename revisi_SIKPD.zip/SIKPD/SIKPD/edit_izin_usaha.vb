﻿Imports MySql.Data.MySqlClient
Public Class edit_izin_usaha
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_izinusaha As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Sub Clear()
        etxt_nama.Text = ""
        etxt_tempat_lahir.Text = ""
        etxt_tgl_lahir.Value = Date.Now
        etxt_tgl_pengajuan.Value = Date.Now
        etxt_bidang_usaha.Text = ""
        ecmb_agama.SelectedItem = ""
        etxt_nama_usaha.Text = ""
        etxt_tempat_lahir.Text = ""
        etxt_alamat.Text = ""
        etxt_alamat_usaha.Text = ""
    End Sub
    Sub Data_Record()
        tb_izinusaha = Proses.ExecuteQuery("Select * From tb_ijinusaha order by id_ijin_usaha DESC")
        Menu_Data_Izin_Usaha.DataGridView1.DataSource = tb_izinusaha
        Menu_Data_Izin_Usaha.DataGridView1.Columns(0).HeaderText = "ID"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(0).Width = 100
        Menu_Data_Izin_Usaha.DataGridView1.Columns(1).HeaderText = "TGL PENGAJUAN"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(1).Width = 100
        Menu_Data_Izin_Usaha.DataGridView1.Columns(2).HeaderText = "NIK"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(2).Width = 150
        Menu_Data_Izin_Usaha.DataGridView1.Columns(3).HeaderText = "NAMA"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(3).Width = 150
        Menu_Data_Izin_Usaha.DataGridView1.Columns(4).HeaderText = "TEMPAT LAHIR"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(4).Width = 150
        Menu_Data_Izin_Usaha.DataGridView1.Columns(5).HeaderText = "TGL LAHIR"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(5).Width = 150
        Menu_Data_Izin_Usaha.DataGridView1.Columns(6).HeaderText = "JENIS KELAMIN"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(6).Width = 100
        Menu_Data_Izin_Usaha.DataGridView1.Columns(7).HeaderText = "ALAMAT"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(7).Width = 200
        Menu_Data_Izin_Usaha.DataGridView1.Columns(8).HeaderText = "AGAMA"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(8).Width = 100
        Menu_Data_Izin_Usaha.DataGridView1.Columns(9).HeaderText = "NAMA USAHA"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(9).Width = 100
        Menu_Data_Izin_Usaha.DataGridView1.Columns(10).HeaderText = "BIDANG USAHA"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(10).Width = 100
        Menu_Data_Izin_Usaha.DataGridView1.Columns(11).HeaderText = "ALAMAT TEMPAT USAHA"
        Menu_Data_Izin_Usaha.DataGridView1.Columns(11).Width = 200
    End Sub

    Private Sub ebtn_simpan_Click(sender As Object, e As EventArgs) Handles ebtn_simpan.Click
        Dim jk As New TextBox
        If (erbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If
        If etxt_nik.Text = "" Then etxt_nik.Focus() : Exit Sub
        If etxt_nama_usaha.Text = "" Then etxt_nama_usaha.Focus() : Exit Sub
        If etxt_bidang_usaha.Text = "" Then etxt_bidang_usaha.Focus() : Exit Sub
        If etxt_alamat_usaha.Text = "" Then etxt_alamat_usaha.Focus() : Exit Sub
        SQL = "update tb_ijinusaha set tanggal_pengajuan= '" & Format(etxt_tgl_pengajuan.Value, "yyyy-MM-dd") & "', nik = '" & etxt_nik.Text & "', nama = '" & etxt_nama.Text & "', tempat_lahir = '" & etxt_tempat_lahir.Text & "',tanggal_lahir = '" & Format(etxt_tgl_lahir.Value, "yyyy-MM-dd") & "',jenis_kelamin = '" & jk.Text & "' ,alamat = '" & etxt_alamat.Text & "',agama = '" & ecmb_agama.Text & "',nama_usaha = '" & etxt_nama_usaha.Text & "',bidang_usaha = '" & etxt_bidang_usaha.Text & "',alamat_tempat_usaha= '" & etxt_alamat_usaha.Text & "' where id_ijin_usaha='" & etxt_id.Text & "'"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Disimpan", "Success Message", MessageBoxButtons.OK)
        Me.Close()
        Call Data_Record()
    End Sub

    Private Sub ebtn_batal_Click(sender As Object, e As EventArgs) Handles ebtn_batal.Click
        Call Clear()
        Me.Close()
    End Sub
End Class