﻿Public Class lap_kematian

End Class