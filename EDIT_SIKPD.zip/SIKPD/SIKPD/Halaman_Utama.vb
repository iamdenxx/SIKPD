﻿Imports MySql.Data.MySqlClient
Public Class Halaman_Utama
    Private Sub btn_penduduk_Click(sender As Object, e As EventArgs) Handles btn_penduduk.Click

        Menu_Penduduk.Show()
        Me.Close()
    End Sub

    Private Sub btn_kelahiran_Click(sender As Object, e As EventArgs) Handles btn_kelahiran.Click

        Menu_Data_Kelahiran.Show()
        Me.Close()
    End Sub

    Private Sub btn_kematian_Click(sender As Object, e As EventArgs) Handles btn_kematian.Click

        Menu_Data_Kematian.Show()
        Me.Close()
    End Sub

    Private Sub btn_pindah_Click(sender As Object, e As EventArgs) Handles btn_pindah.Click

        Menu_Data_Pindah.Show()
        Me.Close()
    End Sub

    Private Sub btn_izinusaha_Click(sender As Object, e As EventArgs) Handles btn_izinusaha.Click

        Menu_Data_Izin_Usaha.Show()
        Me.Close()
    End Sub

End Class
