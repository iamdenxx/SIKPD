﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.DataVisualization.Charting
Public Class tambah_data_penduduk
    Dim SQL As String
    Dim Proses As New Koneksi
    Dim tb_penduduk As DataTable
    Dim conn As New MySqlConnection
    Dim myCommand As New MySqlCommand
    Dim myAdapter As New MySqlDataAdapter
    Dim cd As MySqlCommand
    Dim rd As MySqlDataReader
    Dim jk As String
    Sub Data_Record()
        tb_penduduk = Proses.ExecuteQuery("Select * From tb_penduduk")
        Menu_Penduduk.DataGridView1.DataSource = tb_penduduk
        Menu_Penduduk.DataGridView1.Columns(0).HeaderText = "NIK"
        Menu_Penduduk.DataGridView1.Columns(0).Width = 150
        Menu_Penduduk.DataGridView1.Columns(1).HeaderText = "NAMA"
        Menu_Penduduk.DataGridView1.Columns(1).Width = 150
        Menu_Penduduk.DataGridView1.Columns(2).HeaderText = "TEMPAT LAHIR"
        Menu_Penduduk.DataGridView1.Columns(2).Width = 150
        Menu_Penduduk.DataGridView1.Columns(3).HeaderText = "TGL LAHIR"
        Menu_Penduduk.DataGridView1.Columns(3).Width = 150
        Menu_Penduduk.DataGridView1.Columns(4).HeaderText = "ALAMAT"
        Menu_Penduduk.DataGridView1.Columns(4).Width = 150
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "AGAMA"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "JENIS KELAMIN"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "PENDIDIKAN"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "STATUS PERKAWINAN"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "PEKERJAAN"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "KEWARGANEGARAAN"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
        Menu_Penduduk.DataGridView1.Columns(5).HeaderText = "KET"
        Menu_Penduduk.DataGridView1.Columns(5).Width = 100
    End Sub
    Sub Clear()
        txt_nik.Text = ""
        txt_nama.Text = ""
        txt_alamat.Text = ""
        txt_pekerjaan.Text = ""
        txt_pendidikan.Text = ""
        txt_t_lahir.Text = ""
        rbtn_L.Checked = False
        rbtn_P.Checked = False
        txt_tgl.Value = Date.Now
        cmb_agama.Text = ""
        cmb_kewarganegaraan.Text = ""
        cmb_status.Text = ""
    End Sub

    Private Sub btn_simpan_Click(sender As Object, e As EventArgs) Handles btn_simpan.Click
        Dim jk As New TextBox
        Dim k As New TextBox

        k.Text = "-"

        If (rbtn_L.Checked) Then
            jk.Text = "Laki-Laki"
        Else
            jk.Text = "Perempuan"
        End If
        If txt_nik.Text = "" Then txt_nik.Focus() : Exit Sub
        If txt_t_lahir.Text = "" Then txt_t_lahir.Focus() : Exit Sub
        If txt_alamat.Text = "" Then txt_alamat.Focus() : Exit Sub
        If txt_pekerjaan.Text = "" Then txt_pekerjaan.Focus() : Exit Sub
        If txt_pendidikan.Text = "" Then txt_pendidikan.Focus() : Exit Sub
        SQL = "Insert Into tb_penduduk (nik, nama,tempat_lahir, tanggal_lahir, jenis_kelamin, alamat, agama, pekerjaan,pendidikan, kewarganegaraan, status_perkawinan,ket) Values ('" & txt_nik.Text & "','" & txt_nama.Text & "','" & txt_t_lahir.Text & "','" & Format(txt_tgl.Value, "yyyy-MM-dd") & "','" & jk.Text & "','" & txt_alamat.Text & "','" & cmb_agama.Text & "','" & txt_pekerjaan.Text & "','" & txt_pendidikan.Text & "','" & cmb_kewarganegaraan.Text & "','" & cmb_status.Text & "','" & k.Text & "')"
        Proses.ExecuteNonQuery(SQL)
        MessageBox.Show("Data Berhasil Ditambahkan", "Success Message", MessageBoxButtons.OK)
        Dim msg As DialogResult
        msg = MessageBox.Show("Ada Data yang akan diinputkan lagi ?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If msg = Windows.Forms.DialogResult.No Then
            Call Data_Chart()
            Call Data_Record()
            Me.Close()
        Else
            Call Clear()
        End If

    End Sub
    Sub Data_Chart()
        conn = New MySqlConnection
        conn.ConnectionString =
       "server=localhost;userid=root;password=;database=sikpd"
        Dim READER As MySqlDataReader

        Try
            conn.Open()
            Dim Query As String
            Query = "SELECT COUNT(IF(jenis_kelamin LIKE 'perempuan%',0,NULL)) AS p,COUNT(IF(jenis_kelamin LIKE 'laki-laki%',0,NULL)) AS l FROM tb_penduduk where ket ='-' "
            cd = New MySqlCommand(Query, conn)
            READER = cd.ExecuteReader
            While READER.Read
                With Menu_Penduduk.Chart1
                    .Legends.Clear()
                    .Series.Clear()
                    .ChartAreas.Clear()
                End With

                Dim areas1 As ChartArea = Menu_Penduduk.Chart1.ChartAreas.Add("Areas1")

                With areas1
                End With

                Dim series1 As Series = Menu_Penduduk.Chart1.Series.Add("Series1")

                With series1
                    .ChartArea = areas1.Name
                    .ChartType = SeriesChartType.Pie
                    .Points.AddXY("Perempuan", READER("p"))
                    .Points.AddXY("Laki-Laki", READER("l"))
                End With

                Dim legends1 As Legend = Menu_Penduduk.Chart1.Legends.Add("Legends1")

            End While
            conn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try
    End Sub
    Private Sub btn_batal_Click(sender As Object, e As EventArgs) Handles btn_batal.Click
        Call Clear()
        Me.Close()
    End Sub
End Class